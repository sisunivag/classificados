<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', ['as'=>'site.home', function(){
    return view('site.home');
}]);

Route::get('/sobre', ['as'=>'site.sobre',
    'uses'=>'Site\PaginaController@sobre'
]);

Route::get('/contato', ['as'=>'site.contato',
    'uses'=>'Site\PaginaController@contato'
]);
Route::post('/contato', ['as'=>'site.contato',
    'uses'=>'Site\PaginaController@enviarContato'
]);

Route::get('/anuncio/{id}/{titulo?}', ['as'=>'site.anuncio', function(){
    return view('site.anuncio');
}]);

Route::get('/admin/login', ['as'=>'admin.login', function(){
    return view('admin.login.index');
}]);

Route::post('/admin/login', ['as'=>'admin.login',
    'uses'=>'Admin\UsuarioController@login'
]);

Route::group(['middleware'=>'protegido'], function(){
    Route::get('/admin', ['as'=>'admin.home', function(){
        return view('admin.home.index');
    }]);

    Route::get('/admin/logout', ['as'=>'admin.logout',
        'uses'=>'Admin\UsuarioController@logout'
    ]);

    Route::get('/admin/usuarios', ['as'=>'admin.usuarios',
        'uses'=>'Admin\UsuarioController@index'
    ]);

    Route::get('/admin/usuarios/cadastrar', ['as'=>'admin.usuarios.cadastrar',
        'uses'=>'Admin\UsuarioController@cadastrar'
    ]);
    Route::post('/admin/usuarios/salvar', ['as'=>'admin.usuarios.salvar',
        'uses'=>'Admin\UsuarioController@salvar'
    ]);

    Route::get('/admin/usuarios/alterar/{id}', ['as'=>'admin.usuarios.alterar',
        'uses'=>'Admin\UsuarioController@alterar'
    ]);
    Route::put('/admin/usuarios/atualizar/{id}', ['as'=>'admin.usuarios.atualizar',
        'uses'=>'Admin\UsuarioController@atualizar'
    ]);

    Route::delete('/admin/usuarios/excluir/{id}', ['as'=>'admin.usuarios.excluir',
        'uses'=>'Admin\UsuarioController@excluir'
    ]);

    Route::get('/admin/paginas', ['as'=>'admin.paginas',
        'uses'=>'Admin\PaginaController@index'
    ]);
    Route::get('/admin/paginas/alterar/{id}', ['as'=>'admin.paginas.alterar',
        'uses'=>'Admin\PaginaController@alterar'
    ]);
    Route::put('/admin/paginas/atualizar/{id}', ['as'=>'admin.paginas.atualizar',
        'uses'=>'Admin\PaginaController@atualizar'
    ]);

    Route::get('/admin/tipos', ['as'=>'admin.tipos',
        'uses'=>'Admin\TipoController@index'
    ]);
    Route::get('/admin/tipos/cadastrar', ['as'=>'admin.tipos.cadastrar',
        'uses'=>'Admin\TipoController@cadastrar'
    ]);
    Route::post('/admin/tipos/salvar', ['as'=>'admin.tipos.salvar',
        'uses'=>'Admin\TipoController@salvar'
    ]);
    Route::get('/admin/tipos/alterar/{id}', ['as'=>'admin.tipos.alterar',
        'uses'=>'Admin\TipoController@alterar'
    ]);
    Route::put('/admin/tipos/atualizar/{id}', ['as'=>'admin.tipos.atualizar',
        'uses'=>'Admin\TipoController@atualizar'
    ]);
    Route::delete('/admin/tipos/excluir/{id}', ['as'=>'admin.tipos.excluir',
        'uses'=>'Admin\TipoController@excluir'
    ]);

    Route::get('/admin/municipios', ['as'=>'admin.municipios',
        'uses'=>'Admin\MunicipioController@index'
    ]);
    Route::get('/admin/municipios/cadastrar', ['as'=>'admin.municipios.cadastrar',
        'uses'=>'Admin\MunicipioController@cadastrar'
    ]);
    Route::post('/admin/municipios/salvar', ['as'=>'admin.municipios.salvar',
        'uses'=>'Admin\MunicipioController@salvar'
    ]);
    Route::get('/admin/municipios/alterar/{id}', ['as'=>'admin.municipios.alterar',
        'uses'=>'Admin\MunicipioController@alterar'
    ]);
    Route::put('/admin/municipios/atualizar/{id}', ['as'=>'admin.municipios.atualizar',
        'uses'=>'Admin\MunicipioController@atualizar'
    ]);
    Route::delete('/admin/municipios/excluir/{id}', ['as'=>'admin.municipios.excluir',
        'uses'=>'Admin\MunicipioController@excluir'
    ]);

    Route::get('/admin/anuncios', ['as'=>'admin.anuncios',
        'uses'=>'Admin\AnuncioController@index'
    ]);
    Route::get('/admin/anuncios/cadastrar', ['as'=>'admin.anuncios.cadastrar',
        'uses'=>'Admin\AnuncioController@cadastrar'
    ]);
    Route::post('/admin/anuncios/salvar', ['as'=>'admin.anuncios.salvar',
        'uses'=>'Admin\AnuncioController@salvar'
    ]);
    Route::get('/admin/anuncios/alterar/{id}', ['as'=>'admin.anuncios.alterar',
        'uses'=>'Admin\AnuncioController@alterar'
    ]);
    Route::put('/admin/anuncios/atualizar/{id}', ['as'=>'admin.anuncios.atualizar',
        'uses'=>'Admin\AnuncioController@atualizar'
    ]);
    Route::delete('/admin/anuncios/excluir/{id}', ['as'=>'admin.anuncios.excluir',
        'uses'=>'Admin\AnuncioController@excluir'
    ]);

    Route::get('/admin/imagens/{id}', ['as'=>'admin.imagens',
        'uses'=>'Admin\ImagemController@index'
    ]);
    Route::get('/admin/imagens/cadastrar/{id}', ['as'=>'admin.imagens.cadastrar',
        'uses'=>'Admin\ImagemController@cadastrar'
    ]);
    Route::post('/admin/imagens/salvar/{id}', ['as'=>'admin.imagens.salvar',
        'uses'=>'Admin\ImagemController@salvar'
    ]);
    Route::get('/admin/imagens/alterar/{id}', ['as'=>'admin.imagens.alterar',
        'uses'=>'Admin\ImagemController@alterar'
    ]);
    Route::put('/admin/imagens/atualizar/{id}', ['as'=>'admin.imagens.atualizar',
        'uses'=>'Admin\ImagemController@atualizar'
    ]);
    Route::delete('/admin/imagens/excluir/{id}', ['as'=>'admin.imagens.excluir',
        'uses'=>'Admin\ImagemController@excluir'
    ]);
});
