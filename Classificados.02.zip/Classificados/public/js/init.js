$(document).ready(function(){
    $('.sidenav').sidenav();
    $('.slider').slider({full_width: true});
    $('select').formSelect();
});

function sliderPrev() {
  $('.slider').slider('prev');
  $('.slider').slider('pause');
}

function sliderNext() {
  $('.slider').slider('next');
  $('.slider').slider('pause');
}
