@extends('layouts.site')

@section('content')
<div class="container">
    <div class="row section">
        <h3 align="center">Sobre</h3>
        <div class="divider"></div>
    </div>
    <div class="row section">
        <div class="col s12 m6">
            <img class="responsive-img" src="{{ asset('img/classificados.png') }}" alt="">
        </div>
        <div class="col s12 m6">
            <h4>Sobre a empresa</h4>
            <blockquote>Breve descrição sobre a empresa.</blockquote>
            <p>Texto detalhado sobre a empresa.</p>
        </div>
    </div>
</div>
@endsection
