<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row section">
        <h3 align="center">Sobre</h3>
        <div class="divider"></div>
    </div>
    <div class="row section">
        <div class="col s12 m6">
            <img class="responsive-img" src="<?php echo e(asset('img/classificados.png')); ?>" alt="">
        </div>
        <div class="col s12 m6">
            <h4>Sobre a empresa</h4>
            <blockquote>Breve descrição sobre a empresa.</blockquote>
            <p>Texto detalhado sobre a empresa.</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>