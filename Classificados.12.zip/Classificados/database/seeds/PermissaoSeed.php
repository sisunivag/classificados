<?php

use Illuminate\Database\Seeder;
use App\Permissao;

class PermissaoSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        if (!Permissao::where('nome', '=', 'listar-usuarios')->count()) {
            Permissao::create(['nome'=>'listar-usuario', 'descricao'=>'Listar Usuários']);
        } else {
            $permissao = Permissao::where('nome', '=', 'listar-usuarios')->first();
            $permissao->update(['nome'=>'listar-usuario', 'descricao'=>'Listar Usuários']);
        }

        if (!Permissao::where('nome', '=', 'cadastrar-usuarios')->count()) {
            Permissao::create(['nome'=>'cadastrar-usuario', 'descricao'=>'Cadastrar Usuários']);
        } else {
            $permissao = Permissao::where('nome', '=', 'cadastrar-usuarios')->first();
            $permissao->update(['nome'=>'cadastrar-usuario', 'descricao'=>'Cadastrar Usuários']);
        }

        if (!Permissao::where('nome', '=', 'alterar-usuarios')->count()) {
            Permissao::create(['nome'=>'alterar-usuario', 'descricao'=>'Alterar Usuários']);
        } else {
            $permissao = Permissao::where('nome', '=', 'alterar-usuarios')->first();
            $permissao->update(['nome'=>'alterar-usuario', 'descricao'=>'Alterar Usuários']);
        }

        if (!Permissao::where('nome', '=', 'excluir-usuarios')->count()) {
            Permissao::create(['nome'=>'excluir-usuario', 'descricao'=>'Excluir Usuários']);
        } else {
            $permissao = Permissao::where('nome', '=', 'excluir-usuarios')->first();
            $permissao->update(['nome'=>'excluir-usuario', 'descricao'=>'Excluir Usuários']);
        }
    }
}
