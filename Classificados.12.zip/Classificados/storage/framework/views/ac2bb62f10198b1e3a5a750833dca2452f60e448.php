<div class="input-field">
    <input type="text" name="nome" id="nome" class="validate"
        value="<?php echo e(isset($registro->nome) ? $registro->nome : ''); ?>">
    <label for="nome">Nome</label>
</div>
<div class="input-field">
    <input type="text" name="estado" id="estado" class="validate"
        value="<?php echo e(isset($registro->estado) ? $registro->estado : ''); ?>">
    <label for="estado">Estado</label>
</div>
<div class="input-field">
    <input type="text" name="sigla_estado" id="sigla_estado" class="validate"
        value="<?php echo e(isset($registro->sigla_estado) ? $registro->sigla_estado : ''); ?>">
    <label for="sigla_estado">Sigla do Estado</label>
</div>
