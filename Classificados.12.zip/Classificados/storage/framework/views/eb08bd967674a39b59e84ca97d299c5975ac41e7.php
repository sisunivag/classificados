<div class="row">
    <form action="<?php echo e(route('site.busca')); ?>">
        <div class="input-field col s6 m4">
            <select name="finalidade" id="finalidade">
                <option value="Todos"
                    <?php echo e(isset($busca['finalidade']) && $busca['finalidade'] == 'Todos' ? 'selected' : ''); ?>

                    >Todos</option>
                <option value="Aluguel"
                    <?php echo e(isset($busca['finalidade']) && $busca['finalidade'] == 'Aluguel' ? 'selected' : ''); ?>

                    >Aluguel</option>
                <option value="Troca"
                    <?php echo e(isset($busca['finalidade']) && $busca['finalidade'] == 'Troca' ? 'selected' : ''); ?>

                    >Troca</option>
                <option value="Venda"
                    <?php echo e(isset($busca['finalidade']) && $busca['finalidade'] == 'Venda' ? 'selected' : ''); ?>

                    >Venda</option>
            </select>
            <label for="finalidade">Finalidade</label>
        </div>
        <div class="input-field col s6 m4">
            <select name="tipo_id" id="tipo_id">
                <option value="Todos"
                    <?php echo e(isset($busca['tipo_id']) && $busca['tipo_id'] == 'Todos' ? 'selected' : ''); ?>

                    >Todos</option>
                <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tipo->id); ?>"
                    <?php echo e(isset($busca['tipo_id']) && $busca['tipo_id'] == $tipo->id ? 'selected' : ''); ?>

                    ><?php echo e($tipo->titulo); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="tipo_id">Tipo do Anúncio</label>
        </div>
        <div class="input-field col s6 m4">
            <select name="municipio_id" id="municipio_id">
                <option value="Todos"
                    <?php echo e(isset($busca['municipio_id']) && $busca['municipio_id'] == 'Todos' ? 'selected' : ''); ?>

                    >Todos</option>
                <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($municipio->id); ?>"
                    <?php echo e(isset($busca['municipio_id']) && $busca['municipio_id'] == $municipio->id ? 'selected' : ''); ?>

                    ><?php echo e($municipio->nome); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="municipio_id">Município</label>
        </div>
        <div class="input-field col s12 m4">
            <select name="valor" id="valor">
                <option value="0" <?php echo e(isset($busca['valor']) && $busca['valor'] == 'Todos' ? 'selected' : ''); ?>

                    >Todos</option>
                <option value="1" <?php echo e(isset($busca['valor']) && $busca['valor'] == '1' ? 'selected' : ''); ?>

                    >Até <?php echo e(number_format($valores[1][0][2], 2, ",", ".")); ?></option>
                <?php for($i = 2; $i < count ($valores) - 1; $i++): ?>
                <option value="<?php echo e($i); ?>" <?php echo e(isset($busca['valor']) && $busca['valor'] == $i ? 'selected' : ''); ?>

                    >R$ <?php echo e(number_format($valores[$i][0][2], 2, ",", ".")); ?>

                     a <?php echo e(number_format($valores[$i][1][2], 2, ",", ".")); ?></option>
                <?php endfor; ?>
                <option value="<?php echo e(count($valores) - 1); ?>"
                    <?php echo e(isset($busca['valor']) && $busca['valor'] == count($valores) - 1 ? 'selected' : ''); ?>

                    >Acima de R$ <?php echo e(number_format($valores[count($valores) - 1][0][2], 2, ",", ".")); ?></option>
            </select>
            <label for="valor">Valor</label>
        </div>
        <div class="input-field col s12 m3">
            <input type="text" class="validate" name="endereco" id="endereco"
                value="<?php echo e(isset($busca['endereco']) ? $busca['endereco'] : ''); ?>">
            <label for="endereco">Endereço</label>
        </div>
        <div class="input-field col s12 m2">
            <button class="btn deep-orange darken-1 right">Filtrar</button>
        </div>
    </form>
</div>
