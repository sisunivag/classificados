<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="center">Lista de Papéis</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="<?php echo e(route('admin.home')); ?>" class="breadcrumb">Início</a>
                    <a class="breadcrumb">Lista de Papéis</a>
                </div>
            </div>
        </nav>
    </div>
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($registro->id); ?></td>
                <td><?php echo e($registro->nome); ?></td>
                <td><?php echo e($registro->descricao); ?></td>
                <td>
                    <form action="<?php echo e(route('admin.papeis.excluir', $registro->id)); ?>"
                        method="post"
                        onsubmit="return confirm('Excluir <?php echo e($registro->nome); ?>?')">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('delete')); ?>

                        <?php if($registro->nome != 'admin'): ?>
                        <a href="<?php echo e(route('admin.papeis.alterar', $registro->id)); ?>" class="btn orange">Alterar</a>
                        <button class="btn red">Excluir</button>
                        <?php else: ?>
                        <a href="<?php echo e(route('admin.papeis.alterar', $registro->id)); ?>" class="btn disabled">Alterar</a>
                        <button class="btn disabled">Excluir</button>
                        <?php endif; ?>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="row">
        <a class="btn blue" href="<?php echo e(route('admin.papeis.cadastrar')); ?>">Cadastrar</a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>