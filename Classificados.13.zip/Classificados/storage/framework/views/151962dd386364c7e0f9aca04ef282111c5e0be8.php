<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row section">
        <h3 align="center">Contato</h3>
        <div class="divider"></div>
    </div>
    <div class="row section">
        <div class="col s12 m7">
            <?php if(isset($pagina->mapa)): ?>
            <div class="video-container">
                <?php echo $pagina->mapa; ?>

            </div>
            <?php else: ?>
            <img class="responsive-img" src="<?php echo e(asset($pagina->imagem)); ?>" alt="">
            <?php endif; ?>
        </div>
        <div class="col s12 m5">
            <h4><?php echo e($pagina->titulo); ?></h4>
            <blockquote><?php echo e($pagina->descricao); ?></blockquote>
            <form action="<?php echo e(route('site.contato')); ?>" method="post" class="col s12">
                <?php echo e(@csrf_field()); ?>

                <div class="input-field">
                    <input type="text" name="nome" class="validate" required>
                    <label for="nome">Nome</label>
                </div>
                <div class="input-field">
                    <input type="email" name="email" class="validate" required>
                    <label for="email">E-mail</label>
                </div>
                <div class="input-field">
                    <textarea name="mensagem" class="materialize-textarea" required></textarea>
                    <label for="mensagem">Mensagem</label>
                </div>
                <button class="btn blue">Enviar</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>