<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="center">Lista de Anúncios</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="<?php echo e(route('admin.home')); ?>" class="breadcrumb">Início</a>
                    <a class="breadcrumb">Lista de Anúncios</a>
                </div>
            </div>
        </nav>
    </div>
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Título</th>
                <th>Finalidade</th>
                <th>Município</th>
                <th>Valor</th>
                <th>Imagem</th>
                <th>Publicado</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($registro->id); ?></td>
                <td><?php echo e($registro->titulo); ?></td>
                <td><?php echo e($registro->finalidade); ?></td>
                <td><?php echo e($registro->municipio->nome); ?></td>
                <td>R$ <?php echo e(number_format($registro->valor, 2, ",", ".")); ?></td>
                <td><img src="<?php echo e(asset($registro->imagem)); ?>" alt="" width="100"></td>
                <td><?php echo e($registro->publicado); ?></td>
                <td>
                    <form action="<?php echo e(route('admin.anuncios.excluir', $registro->id)); ?>"
                        method="post"
                        onsubmit="return confirm('Excluir <?php echo e($registro->titulo); ?>?')">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('delete')); ?>

                        <a href="<?php echo e(route('admin.imagens', $registro->id)); ?>" class="btn blue">Galeria de Imagens</a><br />
                        <a href="<?php echo e(route('admin.anuncios.alterar', $registro->id)); ?>" class="btn orange">Alterar</a>
                        <button class="btn red">Excluir</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="row">
        <a class="btn blue" href="<?php echo e(route('admin.anuncios.cadastrar')); ?>">Cadastrar</a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>