<?php

namespace App\Http\Controllers\Admin;

use App\Anuncio;
use App\Imagem;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ImagemController extends Controller
{
    public function index($id)
    {
        $anuncio = Anuncio::find($id);
        $registros = $anuncio->imagens()->orderBy('ordem')->get();
        return view('admin.imagens.index',  compact('registros', 'anuncio'));
    }

    public function cadastrar($id)
    {
        $anuncio = Anuncio::find($id);
        return view('admin.imagens.cadastrar', compact('anuncio'));
    }

    public function salvar(Request $request, $id)
    {
        $anuncio = Anuncio::find($id);
        if ($anuncio->imagens()->count()) {
            $ultimaImagem = $anuncio->imagens()->orderBy('ordem', 'desc')->first();
            $ordem = $ultimaImagem->ordem;
        } else {
            $ordem = 0;
        }

        if ($request->hasFile('imagens')) {
            $folder = "img/anuncios/".str_slug($anuncio->titulo, '_')."/";

            $files = $request->file('imagens');
            foreach ($files as $file) {
                $registro = new Imagem();
                $registro->anuncio_id = $anuncio->id;
                $registro->ordem = ++$ordem;

                $rand = rand(10000, 99999);
                $ext = $file->guessClientExtension();
                $fileName = "_img_".$rand.".".$ext;
                $file->move($folder, $fileName);
                $registro->imagem = $folder.$fileName;
                $registro->save();
            }
        }

        \Session::flash('mensagem', ['msg'=>'Registro cadastrado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.imagens', $anuncio->id);
    }

    public function alterar($id)
    {
        $registro = Imagem::find($id);

        return view('admin.imagens.alterar', compact('registro'));
    }

    public function atualizar(Request $request, $id)
    {
        $registro = Imagem::find($id);
        $dados = $request->all();

        $registro->titulo = $dados['titulo'];
        $registro->descricao = $dados['descricao'];
        $registro->ordem = $dados['ordem'];

        $file = $request->file('imagem');
        if ($file) {
            $rand = rand(10000, 99999);
            $folder = "img/anuncios/".str_slug($registro->anuncio->titulo, '_')."/";
            $ext = $file->guessClientExtension();
            $fileName = "_img_".$rand.".".$ext;
            $file->move($folder, $fileName);
            $registro->imagem = $folder.$fileName;
        }

        $registro->update();

        \Session::flash('mensagem', ['msg'=>'Registro atualizado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.imagens', $registro->anuncio->id);
    }

    public function excluir($id)
    {
        $imagem = Imagem::find($id);
        $anuncio = $imagem->anuncio;

        $imagem->delete();

        \Session::flash('mensagem', ['msg'=>'Registro excluído com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.imagens', $anuncio->id);
    }
}
