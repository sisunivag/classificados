<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Anuncio;
use App\Municipio;
use App\Tipo;

class AnuncioController extends Controller
{
    public function index()
    {
        $registros = Anuncio::all();
        return view('admin.anuncios.index',  compact('registros'));
    }

    public function cadastrar()
    {
        $tipos = Tipo::all()->sortBy('titulo');
        $municipios = Municipio::all()->sortBy('nome');

        return view('admin.anuncios.cadastrar', compact('tipos', 'municipios'));
    }

    public function salvar(Request $request)
    {
        $dados = $request->all();

        $registro = new Anuncio();
        $registro->municipio_id = $dados['municipio_id'];
        $registro->tipo_id = $dados['tipo_id'];
        $registro->titulo = $dados['titulo'];
        $registro->descricao = $dados['descricao'];
        $registro->finalidade = $dados['finalidade'];
        $registro->endereco = $dados['endereco'];
        $registro->cep = $dados['cep'];
        $registro->valor = $dados['valor'];
        $registro->detalhes = $dados['detalhes'];
        $registro->visualizacoes = 0;
        $registro->publicado = $dados['publicado'];

        if(isset($dados['mapa']) && trim($dados['mapa']) != '') {
            $registro->mapa = trim($dados['mapa']);
        } else {
            $registro->mapa = null;
        }

        $file = $request->file('imagem');
        if ($file) {
            $rand = rand(10000, 99999);
            $folder = "img/anuncios/".str_slug($dados['titulo'], '_')."/";
            $ext = $file->guessClientExtension();
            $fileName = "_img_".$rand.".".$ext;
            $file->move($folder, $fileName);
            $registro->imagem = $folder.$fileName;
        }

        $registro->save();

        \Session::flash('mensagem', ['msg'=>'Registro cadastrado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.anuncios');
    }

    public function alterar($id)
    {
        $registro = Anuncio::find($id);
        $tipos = Tipo::all()->sortBy('titulo');
        $municipios = Municipio::all()->sortBy('nome');

        return view('admin.anuncios.alterar', compact('registro', 'tipos', 'municipios'));
    }

    public function atualizar(Request $request, $id)
    {
        $registro = Anuncio::find($id);
        $dados = $request->all();

        $registro->municipio_id = $dados['municipio_id'];
        $registro->tipo_id = $dados['tipo_id'];
        $registro->titulo = $dados['titulo'];
        $registro->descricao = $dados['descricao'];
        $registro->finalidade = $dados['finalidade'];
        $registro->endereco = $dados['endereco'];
        $registro->cep = $dados['cep'];
        $registro->valor = $dados['valor'];
        $registro->detalhes = $dados['detalhes'];
        $registro->publicado = $dados['publicado'];

        if(isset($dados['mapa']) && trim($dados['mapa']) != '') {
            $registro->mapa = trim($dados['mapa']);
        } else {
            $registro->mapa = null;
        }

        $file = $request->file('imagem');
        if ($file) {
            $rand = rand(10000, 99999);
            $folder = "img/anuncios/".str_slug($dados['titulo'], '_')."/";
            $ext = $file->guessClientExtension();
            $fileName = "_img_".$rand.".".$ext;
            $file->move($folder, $fileName);
            $registro->imagem = $folder.$fileName;
        }

        $registro->update();

        \Session::flash('mensagem', ['msg'=>'Registro atualizado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.anuncios');
    }

    public function excluir($id)
    {
        Anuncio::find($id)->delete();

        \Session::flash('mensagem', ['msg'=>'Registro excluído com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.anuncios');
    }
}
