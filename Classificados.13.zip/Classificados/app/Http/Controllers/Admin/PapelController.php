<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Papel;
use App\Permissao;

class PapelController extends Controller
{
    public function index()
    {
        if (!auth()->user()->can('listar-papeis')) {
            \Session::flash('mensagem', ['msg'=>'Erro: Você não pode listar os papéis.',
                'css-class'=>'red lighten-4']);
            return redirect()->route('admin.home');
        }

        $registros = Papel::all();
        return view('admin.papeis.index',  compact('registros'));
    }

    public function cadastrar()
    {
        if (!auth()->user()->can('cadastrar-papel')) {
            \Session::flash('mensagem', ['msg'=>'Erro: Você não pode cadastrar papel.',
                'css-class'=>'red lighten-4']);
            return redirect()->route('admin.home');
        }

        return view('admin.papeis.cadastrar');
    }

    public function salvar(Request $request)
    {
        if (!auth()->user()->can('cadastrar-papel')) {
            \Session::flash('mensagem', ['msg'=>'Erro: Você não pode cadastrar papel.',
                'css-class'=>'red lighten-4']);
            return redirect()->route('admin.home');
        }

        $dados = $request->all();

        if (!Papel::where('nome', '=', $dados['nome'])->count()) {
            Papel::create($dados);

            \Session::flash('mensagem', ['msg'=>'Registro cadastrado com sucesso!',
                'css-class'=>'green lighten-4']);
        } else {
            \Session::flash('mensagem', ['msg'=>'Erro: O papel "'.$dados['nome'].'" já existe.',
                'css-class'=>'red lighten-4']);
        }

        return redirect()->route('admin.papeis');
    }

    public function alterar($id)
    {
        if (!auth()->user()->can('alterar-papel')) {
            \Session::flash('mensagem', ['msg'=>'Erro: Você não pode alterar papel.',
                'css-class'=>'red lighten-4']);
            return redirect()->route('admin.home');
        }

        $registro = Papel::find($id);

        if ($registro->nome == 'admin') {
            \Session::flash('mensagem', ['msg'=>'Erro: O papel "admin" não pode ser alterado.',
                'css-class'=>'red lighten-4']);

                return redirect()->route('admin.papeis');
        }

        return view('admin.papeis.alterar', compact('registro'));
    }

    public function atualizar(Request $request, $id)
    {
        if (!auth()->user()->can('alterar-papel')) {
            \Session::flash('mensagem', ['msg'=>'Erro: Você não pode alterar papel.',
                'css-class'=>'red lighten-4']);
            return redirect()->route('admin.home');
        }

        $registro = Papel::find($id);

        if ($registro->nome == 'admin') {
            \Session::flash('mensagem', ['msg'=>'Erro: O papel "admin" não pode ser alterado.',
                'css-class'=>'red lighten-4']);
        } else {
            $registro->update($request->all());

            \Session::flash('mensagem', ['msg'=>'Registro atualizado com sucesso!',
                'css-class'=>'green lighten-4']);
        }

        return redirect()->route('admin.papeis');
    }

    public function excluir($id)
    {
        if (!auth()->user()->can('excluir-papel')) {
            \Session::flash('mensagem', ['msg'=>'Erro: Você não pode excluir papel.',
                'css-class'=>'red lighten-4']);
            return redirect()->route('admin.home');
        }

        $registro = Papel::find($id);

        if ($registro->nome == 'admin') {
            \Session::flash('mensagem', ['msg'=>'Erro: O papel "admin" não pode ser excluído.',
                'css-class'=>'red lighten-4']);
        } else {
            $registro->delete();

            \Session::flash('mensagem', ['msg'=>'Registro excluído com sucesso!',
                'css-class'=>'green lighten-4']);
        }

        return redirect()->route('admin.papeis');
    }

    public function permissoes($id)
    {
        $papel = Papel::find($id);
        $permissoes = Permissao::orderBy('nome')->get();
        return view ('admin.papeis.permissoes', compact('papel', 'permissoes'));
    }

    public function permissaoSalvar(Request $request, $id)
    {
        $dados = $request->all();
        $papel = Papel::find($id);
        $permissao = Permissao::find($dados['permissao_id']);
        $papel->adicionarPermissao($permissao);
        return redirect()->back();
    }

    public function permissaoExcluir($id, $permissao_id)
    {
        $papel = Papel::find($id);
        $permissao = Permissao::find($permissao_id);
        $papel->removerPermissao($permissao);
        return redirect()->back();
    }
}
