<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Pagina;

class PaginaController extends Controller
{
    public function index()
    {
        $paginas = Pagina::all();
        return view('admin.paginas.index', compact('paginas'));
    }

    public function alterar($id)
    {
        $pagina = Pagina::find($id);
        return view('admin.paginas.alterar', compact('pagina'));
    }

    public function atualizar(Request $request, $id)
    {
        $dados = $request->all();
        $pagina = Pagina::find($id);
        $pagina->titulo = trim($dados['titulo']);
        $pagina->descricao = trim($dados['descricao']);
        $pagina->texto = trim($dados['texto']);
        if(isset($dados['email'])) {
            $pagina->email = trim($dados['email']);
        }
        if(isset($dados['mapa']) && trim($dados['mapa']) != '') {
            $pagina->mapa = trim($dados['mapa']);
        } else {
            $pagina->mapa = null;
        }
        $file = $request->file('imagem');
        if ($file) {
            $rand = rand(10000, 99999);
            $folder = "img/paginas/".$id."/";
            $ext = $file->guessClientExtension();
            $fileName = "_img_".$rand.".".$ext;
            $file->move($folder, $fileName);
            $pagina->imagem = $folder.$fileName;
        }

        $pagina->update();

        \Session::flash('mensagem', ['msg'=>'Página atualizada com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.paginas');
    }
}
