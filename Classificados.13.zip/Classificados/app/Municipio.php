<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Municipio extends Model
{
    public function anuncios()
    {
        return $this->hasMany('App\Anuncio', 'municipio_id');
    }
}
