@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="center">Lista de Usuários</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="{{ route('admin.home') }}" class="breadcrumb">Início</a>
                    <a class="breadcrumb">Lista de Usuários</a>
                </div>
            </div>
        </nav>
    </div>
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            @foreach($usuarios as $usuario)
            <tr>
                <td>{{ $usuario->id }}</td>
                <td>{{ $usuario->name }}</td>
                <td>{{ $usuario->email }}</td>
                <td>
                    <form action="{{ route('admin.usuarios.excluir', $usuario->id) }}"
                        method="post"
                        onsubmit="return confirm('Excluir {{ $usuario->name }}?')">
                        {{ csrf_field() }}
                        {{ method_field('delete') }}
                        <a href="{{ route('admin.usuarios.papeis', $usuario->id) }}" class="btn blue">Papéis</a>
                        @can('alterar-usuario')
                        <a href="{{ route('admin.usuarios.alterar', $usuario->id) }}" class="btn orange">Alterar</a>
                        @endcan
                        @can('excluir-usuario')
                        <button class="btn red">Excluir</button>
                        @endcan
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <div class="row">
        @can('alterar-usuario')
        <a class="btn blue" href="{{ route('admin.usuarios.cadastrar') }}">Cadastrar</a>
        @endcan
    </div>
</div>

@endsection