@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="center">Cadastrar Usuário</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="{{ route('admin.home') }}" class="breadcrumb">Início</a>
                    <a href="{{ route('admin.usuarios') }}" class="breadcrumb">Lista de Usuários</a>
                    <a class="breadcrumb">Cadastrar Usuário</a>
                </div>
            </div>
        </nav>
    </div>
    <div class="row">
        <form action="{{ route('admin.usuarios.salvar') }}" method="post">
            {{ csrf_field() }}
            @include('admin.usuarios._form')
            <button class="btn blue">Cadastrar</button>
        </form>
    </div>
</div>

@endsection
