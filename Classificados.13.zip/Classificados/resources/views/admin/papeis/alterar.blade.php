@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="center">Alterar Papel</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="{{ route('admin.home') }}" class="breadcrumb">Início</a>
                    <a href="{{ route('admin.papeis') }}" class="breadcrumb">Lista de Papéis</a>
                    <a class="breadcrumb">Alterar Papel</a>
                </div>
            </div>
        </nav>
    </div>
    <div class="row">
        <form action="{{ route('admin.papeis.atualizar', $registro->id) }}" method="post">
            {{ csrf_field() }}
            <input type="hidden" name="_method" value="put">
            @include('admin.papeis._form')
            <button class="btn blue">Alterar</button>
        </form>
    </div>
</div>

@endsection
