@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="center">Lista de Permissões - {{ $papel->nome }}</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="{{ route('admin.home') }}" class="breadcrumb">Início</a>
                    <a href="{{ route('admin.papeis') }}" class="breadcrumb">Lista de Papéis</a>
                    <a class="breadcrumb">Lista de Permissões</a>
                </div>
            </div>
        </nav>
    </div>
    <div class="row">
        <form action="{{ route('admin.papeis.permissao.salvar', $papel->id) }}" method="post">
            {{ csrf_field() }}
            <div class="input field">
                <select name="permissao_id" id="permissao_id">
                    @foreach ($permissoes as $permissao)
                    <option value="{{ $permissao->id }}">{{ $permissao->nome }}</option>
                    @endforeach
                </select>
            </div>
            <button class="btn blue">Cadastrar</button>
        </form>
    </div>
    <div class="row">
        <table>
            <thead>
                <tr>
                    <th>Permissão</th>
                    <th>Descrição</th>
                    <th>Ação</th>
                </tr>
            </thead>
            <tbody>
                @foreach($papel->permissoes as $permissao)
                <tr>
                    <td>{{ $permissao->nome }}</td>
                    <td>{{ $permissao->descricao }}</td>
                    <td>
                        <form action="{{ route('admin.papeis.permissao.excluir', [$papel->id, $permissao->id]) }}"
                            method="post"
                            onsubmit="return confirm('Excluir {{ $permissao->nome }}?')">
                            {{ csrf_field() }}
                            {{ method_field('delete') }}
                            <button class="btn red">Excluir</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

@endsection