@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="center">Lista de Papéis</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="{{ route('admin.home') }}" class="breadcrumb">Início</a>
                    <a class="breadcrumb">Lista de Papéis</a>
                </div>
            </div>
        </nav>
    </div>
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            @foreach($registros as $registro)
            <tr>
                <td>{{ $registro->id }}</td>
                <td>{{ $registro->nome }}</td>
                <td>{{ $registro->descricao }}</td>
                <td>
                    <form action="{{ route('admin.papeis.excluir', $registro->id) }}"
                        method="post"
                        onsubmit="return confirm('Excluir {{ $registro->nome }}?')">
                        {{ csrf_field() }}
                        {{ method_field('delete') }}
                        <a href="{{ route('admin.papeis.permissoes', $registro->id) }}" class="btn blue">Permissões</a>
                        @if($registro->nome != 'admin')
                        @can('alterar-papel')
                        <a href="{{ route('admin.papeis.alterar', $registro->id) }}" class="btn orange">Alterar</a>
                        @endcan
                        @can('excluir-papel')
                        <button class="btn red">Excluir</button>
                        @endcan
                        @else
                        <a href="{{ route('admin.papeis.alterar', $registro->id) }}" class="btn disabled">Alterar</a>
                        <button class="btn disabled">Excluir</button>
                        @endif
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <div class="row">
        @can('cadastrar-papel')
        <a class="btn blue" href="{{ route('admin.papeis.cadastrar') }}">Cadastrar</a>
        @endcan
    </div>
</div>

@endsection