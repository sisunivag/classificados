@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="center">Lista de Municípios</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="{{ route('admin.home') }}" class="breadcrumb">Início</a>
                    <a class="breadcrumb">Lista de Municípios</a>
                </div>
            </div>
        </nav>
    </div>
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Nome</th>
                <th>Estado</th>
                <th>Sigla</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            @foreach($registros as $registro)
            <tr>
                <td>{{ $registro->id }}</td>
                <td>{{ $registro->nome }}</td>
                <td>{{ $registro->estado }}</td>
                <td>{{ $registro->sigla_estado }}</td>
                <td>
                    <form action="{{ route('admin.municipios.excluir', $registro->id) }}"
                        method="post"
                        onsubmit="return confirm('Excluir {{ $registro->nome }}?')">
                        {{ csrf_field() }}
                        {{ method_field('delete') }}
                        <a href="{{ route('admin.municipios.alterar', $registro->id) }}" class="btn orange">Alterar</a>
                        <button class="btn red">Excluir</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <div class="row">
        <a class="btn blue" href="{{ route('admin.municipios.cadastrar') }}">Cadastrar</a>
    </div>
</div>

@endsection