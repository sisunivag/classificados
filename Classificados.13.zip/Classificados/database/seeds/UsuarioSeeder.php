<?php

use Illuminate\Database\Seeder;
use App\User;

class UsuarioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        if (User::where('email', '=', 'admin@classificados.com.br')->count()) {
            $usuario = User::where('email', '=', 'admin@classificados.com.br')->first();
            $usuario->update(['name'=>'Chucky Norris', 'password'=>bcrypt("123456")]);
        } else {
            User::create(['name'=>'Chucky Norris', 'email'=>'admin@classificados.com.br', 'password'=>bcrypt("123456")]);
        }
    }
}
