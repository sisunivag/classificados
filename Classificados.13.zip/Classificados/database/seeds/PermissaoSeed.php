<?php

use Illuminate\Database\Seeder;
use App\Permissao;

class PermissaoSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        if (!Permissao::where('nome', '=', 'listar-usuarios')->count()) {
            Permissao::create(['nome'=>'listar-usuarios', 'descricao'=>'Listar Usuários']);
        } else {
            $permissao = Permissao::where('nome', '=', 'listar-usuarios')->first();
            $permissao->update(['nome'=>'listar-usuarios', 'descricao'=>'Listar Usuários']);
        }

        if (!Permissao::where('nome', '=', 'cadastrar-usuario')->count()) {
            Permissao::create(['nome'=>'cadastrar-usuario', 'descricao'=>'Cadastrar Usuário']);
        } else {
            $permissao = Permissao::where('nome', '=', 'cadastrar-usuario')->first();
            $permissao->update(['nome'=>'cadastrar-usuario', 'descricao'=>'Cadastrar Usuário']);
        }

        if (!Permissao::where('nome', '=', 'alterar-usuario')->count()) {
            Permissao::create(['nome'=>'alterar-usuario', 'descricao'=>'Alterar Usuário']);
        } else {
            $permissao = Permissao::where('nome', '=', 'alterar-usuario')->first();
            $permissao->update(['nome'=>'alterar-usuario', 'descricao'=>'Alterar Usuário']);
        }

        if (!Permissao::where('nome', '=', 'excluir-usuario')->count()) {
            Permissao::create(['nome'=>'excluir-usuario', 'descricao'=>'Excluir Usuário']);
        } else {
            $permissao = Permissao::where('nome', '=', 'excluir-usuario')->first();
            $permissao->update(['nome'=>'excluir-usuario', 'descricao'=>'Excluir Usuário']);
        }

        if (!Permissao::where('nome', '=', 'listar-papeis')->count()) {
            Permissao::create(['nome'=>'listar-papeis', 'descricao'=>'Listar Papéis']);
        } else {
            $permissao = Permissao::where('nome', '=', 'listar-papeis')->first();
            $permissao->update(['nome'=>'listar-papeis', 'descricao'=>'Listar Papéis']);
        }

        if (!Permissao::where('nome', '=', 'cadastrar-papel')->count()) {
            Permissao::create(['nome'=>'cadastrar-papel', 'descricao'=>'Cadastrar Papel']);
        } else {
            $permissao = Permissao::where('nome', '=', 'cadastrar-papel')->first();
            $permissao->update(['nome'=>'cadastrar-papel', 'descricao'=>'Cadastrar Papel']);
        }

        if (!Permissao::where('nome', '=', 'alterar-papel')->count()) {
            Permissao::create(['nome'=>'alterar-papel', 'descricao'=>'Alterar Papel']);
        } else {
            $permissao = Permissao::where('nome', '=', 'alterar-papel')->first();
            $permissao->update(['nome'=>'alterar-papel', 'descricao'=>'Alterar Papel']);
        }

        if (!Permissao::where('nome', '=', 'excluir-papel')->count()) {
            Permissao::create(['nome'=>'excluir-papel', 'descricao'=>'Excluir Papel']);
        } else {
            $permissao = Permissao::where('nome', '=', 'excluir-papel')->first();
            $permissao->update(['nome'=>'excluir-papel', 'descricao'=>'Excluir Papel']);
        }
    }
}
