<?php

use Illuminate\Database\Seeder;
use App\Papel;

class PapelSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        if (!Papel::where('nome', '=', 'admin')->count()) {
            $papel = Papel::create([
                'nome'=>'admin', 'descricao'=>'Administrador do Sistema'
            ]);
        }
        if (!Papel::where('nome', '=', 'gerente')->count()) {
            $papel = Papel::create([
                'nome'=>'gerente', 'descricao'=>'Gerente do Sistema'
            ]);
        }
        if (!Papel::where('nome', '=', 'vendedor')->count()) {
            $papel = Papel::create([
                'nome'=>'vendedor', 'descricao'=>'Equipe de Vendas'
            ]);
        }
    }
}
