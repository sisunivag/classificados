<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="center">Lista de Páginas</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="<?php echo e(route('admin.home')); ?>" class="breadcrumb">Início</a>
                    <a class="breadcrumb">Lista de Páginas</a>
                </div>
            </div>
        </nav>
    </div>
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Título</th>
                <th>Descrição</th>
                <th>Tipo</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $paginas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pagina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pagina->id); ?></td>
                <td><?php echo e($pagina->titulo); ?></td>
                <td><?php echo e($pagina->descricao); ?></td>
                <td><?php echo e($pagina->tipo); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.paginas.alterar', $pagina->id)); ?>" class="btn orange">Alterar</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>