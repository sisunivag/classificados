@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="center">Cadastrar Município</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="{{ route('admin.home') }}" class="breadcrumb">Início</a>
                    <a href="{{ route('admin.municipios') }}" class="breadcrumb">Lista de Municípios</a>
                    <a class="breadcrumb">Cadastrar Município</a>
                </div>
            </div>
        </nav>
    </div>
    <div class="row">
        <form action="{{ route('admin.municipios.salvar') }}" method="post">
            {{ csrf_field() }}
            @include('admin.municipios._form')
            <button class="btn blue">Cadastrar</button>
        </form>
    </div>
</div>

@endsection
