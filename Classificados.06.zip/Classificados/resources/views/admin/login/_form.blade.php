<div class="input-field">
    <input type="email" name="email" id="email" class="validate">
    <label for="email">E-mail</label>
</div>
<div class="input-field">
    <input type="password" name="password" id="password" class="validate">
    <label for="password">Senha</label>
</div>
