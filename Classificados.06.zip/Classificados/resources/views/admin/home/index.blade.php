@extends('layouts.app')

@section('content')

<div class="container">
    <h2>Principal</h2>
</div>

@endsection
