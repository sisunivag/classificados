@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="center">Lista de Tipos</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="{{ route('admin.home') }}" class="breadcrumb">Início</a>
                    <a class="breadcrumb">Lista de Tipos</a>
                </div>
            </div>
        </nav>
    </div>
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Título</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            @foreach($registros as $registro)
            <tr>
                <td>{{ $registro->id }}</td>
                <td>{{ $registro->titulo }}</td>
                <td>
                    <form action="{{ route('admin.tipos.excluir', $registro->id) }}"
                        method="post"
                        onsubmit="return confirm('Excluir {{ $registro->titulo }}?')">
                        {{ csrf_field() }}
                        {{ method_field('delete') }}
                        <a href="{{ route('admin.tipos.alterar', $registro->id) }}" class="btn orange">Alterar</a>
                        <button class="btn red">Excluir</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <div class="row">
        <a class="btn blue" href="{{ route('admin.tipos.cadastrar') }}">Cadastrar</a>
    </div>
</div>

@endsection