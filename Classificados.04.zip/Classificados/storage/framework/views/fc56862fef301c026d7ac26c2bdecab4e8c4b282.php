<div class="slider">
    <ul class="slides">
        <li>
            <img src="<?php echo e(asset('img/slide1.jpeg')); ?>" alt="Carro">
            <div class="caption center-align">
                <h3>Título da imagem</h3>
                <h5>Descrição da imagem</h5>
            </div>
        </li>
        <li>
            <img src="<?php echo e(asset('img/slide2.jpg')); ?>" alt="Videogame">
            <div class="caption left-align">
                <h3>Título da imagem</h3>
                <h5>Descrição da imagem</h5>
            </div>
        </li>
        <li>
            <img src="<?php echo e(asset('img/slide3.jpg')); ?>" alt="Televisor UHD">
            <div class="caption right-align">
                <h3>Título da imagem</h3>
                <h5>Descrição da imagem</h5>
            </div>
        </li>
    </ul>
</div>
