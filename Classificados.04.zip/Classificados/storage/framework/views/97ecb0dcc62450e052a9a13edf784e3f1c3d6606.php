<div class="input-field">
    <input type="text" name="name" id="name" class="validate"
        value="<?php echo e(isset($usuario->name) ? $usuario->name : ''); ?>">
    <label for="name">Nome</label>
</div>
<div class="input-field">
    <input type="text" name="email" id="email" class="validate"
        value="<?php echo e(isset($usuario->email) ? $usuario->email : ''); ?>">
    <label for="email">E-mail</label>
</div>
<div class="input-field">
    <input type="password" name="password" id="password" class="validate">
    <label for="password">Senha</label>
</div>
