<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\User;

class UsuarioController extends Controller
{
    public function login(Request $request)
    {
        $dados = $request->all();
        
        if (Auth::attempt(['email'=>$dados['email'], 'password'=>$dados['password']]))
        {
            \Session::flash('mensagem', ['msg'=>'Login realizado com sucesso!',
                'css-class'=>'green lighten-4']);
            return redirect()->route('admin.home');
        }
        \Session::flash('mensagem', ['msg'=>'Erro: Dados incorretos!',
            'css-class'=>'red lighten-4']);
        return redirect()->route('admin.login');
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('admin.login');
    }

    public function index()
    {
        $usuarios = User::all();
        return view('admin.usuarios.index',  compact('usuarios'));
    }

    public function cadastrar()
    {
        return view('admin.usuarios.cadastrar');
    }

    public function salvar(Request $request)
    {
        $dados = $request->all();

        $usuario = new User();
        $usuario->name = $dados['name'];
        $usuario->email = $dados['email'];
        $usuario->password = bcrypt($dados['password']);

        $usuario->save();

        \Session::flash('mensagem', ['msg'=>'Usuário cadastrado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.usuarios');
    }

    public function alterar($id)
    {
        $usuario = User::find($id);
        return view('admin.usuarios.alterar', compact('usuario'));
    }

    public function atualizar(Request $request, $id)
    {
        $usuario = User::find($id);
        $dados = $request->all();
        if (isset($dados['password']) && strlen($dados['password']) > 5) {
            $dados['password'] = bcrypt($dados['password']);
        } else {
            unset($dados['password']);
        }

        $usuario->update($dados);

        \Session::flash('mensagem', ['msg'=>'Usuário atualizado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.usuarios');
    }

    public function excluir($id)
    {
        User::find($id)->delete();

        \Session::flash('mensagem', ['msg'=>'Usuário excluído com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.usuarios');
    }
}
