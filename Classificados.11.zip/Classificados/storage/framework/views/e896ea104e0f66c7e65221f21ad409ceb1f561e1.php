<div class="input-field">
    <input type="text" name="nome" id="nome" class="validate"
        value="<?php echo e(isset($registro->nome) ? $registro->nome : ''); ?>">
    <label for="nome">Nome</label>
</div>
<div class="input-field">
    <input type="text" name="descricao" id="descricao" class="validate"
        value="<?php echo e(isset($registro->descricao) ? $registro->descricao : ''); ?>">
    <label for="descricao">Descrição</label>
</div>
