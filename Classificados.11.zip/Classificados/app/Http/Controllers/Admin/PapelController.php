<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Papel;

class PapelController extends Controller
{
    public function index()
    {
        $registros = Papel::all();
        return view('admin.papeis.index',  compact('registros'));
    }

    public function cadastrar()
    {
        return view('admin.papeis.cadastrar');
    }

    public function salvar(Request $request)
    {
        Papel::create($request->all());

        \Session::flash('mensagem', ['msg'=>'Registro cadastrado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.papeis');
    }

    public function alterar($id)
    {
        $registro = Papel::find($id);

        if ($registro->nome == 'admin') {
            \Session::flash('mensagem', ['msg'=>'Erro: O papel "admin" não pode ser alterado.',
                'css-class'=>'red lighten-4']);

                return redirect()->route('admin.papeis');
        }

        return view('admin.papeis.alterar', compact('registro'));
    }

    public function atualizar(Request $request, $id)
    {
        $registro = Papel::find($id);

        if ($registro->nome == 'admin') {
            \Session::flash('mensagem', ['msg'=>'Erro: O papel "admin" não pode ser alterado.',
                'css-class'=>'red lighten-4']);
        } else {
            $registro->update($request->all());

            \Session::flash('mensagem', ['msg'=>'Registro atualizado com sucesso!',
                'css-class'=>'green lighten-4']);
        }

        return redirect()->route('admin.papeis');
    }

    public function excluir($id)
    {
        $registro = Papel::find($id);

        if ($registro->nome == 'admin') {
            \Session::flash('mensagem', ['msg'=>'Erro: O papel "admin" não pode ser excluído.',
                'css-class'=>'red lighten-4']);
        } else {
            $registro->delete();

            \Session::flash('mensagem', ['msg'=>'Registro excluído com sucesso!',
                'css-class'=>'green lighten-4']);
        }

        return redirect()->route('admin.papeis');
    }
}
