<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Anuncio;
use App\Tipo;

class TipoController extends Controller
{
    public function index()
    {
        $registros = Tipo::all();
        return view('admin.tipos.index',  compact('registros'));
    }

    public function cadastrar()
    {
        return view('admin.tipos.cadastrar');
    }

    public function salvar(Request $request)
    {
        $dados = $request->all();

        $registro = new Tipo();
        $registro->titulo = $dados['titulo'];

        $registro->save();

        \Session::flash('mensagem', ['msg'=>'Registro cadastrado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.tipos');
    }

    public function alterar($id)
    {
        $registro = Tipo::find($id);
        return view('admin.tipos.alterar', compact('registro'));
    }

    public function atualizar(Request $request, $id)
    {
        $registro = Tipo::find($id);
        $dados = $request->all();
        $registro->titulo = $dados['titulo'];

        $registro->update();

        \Session::flash('mensagem', ['msg'=>'Registro atualizado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.tipos');
    }

    public function excluir($id)
    {
        $tipo = Tipo::find($id);
        if (Anuncio::where('tipo_id', '=', $id)->count()) {
            $msg = 'Erro: Não é possível excluir "'.$tipo->titulo.
                '", pois possui os seguintes anúncios cadastrados:';
            $anuncios = Anuncio::where('tipo_id', '=', $id)->get();
            foreach ($anuncios as $anuncio) {
                $msg .= ' '.$anuncio->id;
            }
            \Session::flash('mensagem', ['msg'=>$msg, 'css-class'=>'red lighten-4']);
            return redirect()->route('admin.tipos');
        }
        $tipo::find($id)->delete();

        \Session::flash('mensagem', ['msg'=>'Registro excluído com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.tipos');
    }
}
