<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Slide;

class SlideController extends Controller
{
    public function index()
    {
        $registros = Slide::orderBy('ordem')->get();
        return view('admin.slides.index',  compact('registros'));
    }

    public function cadastrar()
    {
        return view('admin.slides.cadastrar');
    }

    public function salvar(Request $request)
    {
        if (Slide::count()) {
            $ultimoSlide = Slide::orderBy('ordem', 'desc')->first();
            $ordem = $ultimoSlide->ordem;
        } else {
            $ordem = 0;
        }

        if ($request->hasFile('imagens')) {
            $folder = "img/slides/";

            $files = $request->file('imagens');
            foreach ($files as $file) {
                $registro = new Slide();
                $registro->ordem = ++$ordem;

                $rand = rand(10000, 99999);
                $ext = $file->guessClientExtension();
                $fileName = "_img_".$rand.".".$ext;
                $file->move($folder, $fileName);
                $registro->imagem = $folder.$fileName;
                $registro->save();
            }
        }

        \Session::flash('mensagem', ['msg'=>'Registro cadastrado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.slides');
    }

    public function alterar($id)
    {
        $registro = Slide::find($id);

        return view('admin.slides.alterar', compact('registro'));
    }

    public function atualizar(Request $request, $id)
    {
        $registro = Slide::find($id);
        $dados = $request->all();

        $registro->titulo = $dados['titulo'];
        $registro->descricao = $dados['descricao'];
        $registro->link = $dados['link'];
        $registro->ordem = $dados['ordem'];
        $registro->alinhamento = $dados['alinhamento'];
        $registro->publicado = $dados['publicado'];

        $file = $request->file('imagem');
        if ($file) {
            $rand = rand(10000, 99999);
            $folder = "img/slides/";
            $ext = $file->guessClientExtension();
            $fileName = "_img_".$rand.".".$ext;
            $file->move($folder, $fileName);
            $registro->imagem = $folder.$fileName;
        }

        $registro->update();

        \Session::flash('mensagem', ['msg'=>'Registro atualizado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.slides');
    }

    public function excluir($id)
    {
        Slide::find($id)->delete();

        \Session::flash('mensagem', ['msg'=>'Registro excluído com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.slides');
    }
}
