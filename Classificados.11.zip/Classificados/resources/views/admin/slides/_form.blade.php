@if(isset($registro->imagem))
<div class="input-field">
    <input type="text" name="titulo" id="titulo" class="validate"
        value="{{ isset($registro->titulo) ? $registro->titulo : '' }}">
    <label for="titulo">Título</label>
</div>
<div class="input-field">
    <input type="text" name="descricao" id="descricao" class="validate"
        value="{{ isset($registro->descricao) ? $registro->descricao : '' }}">
    <label for="descricao">Descrição</label>
</div>
<div class="input-field">
    <input type="number" name="ordem"  id="ordem" min="1" step="1" class="validate"
        placeholder="Ex.: 1" value="{{ isset($registro->ordem) ? $registro->ordem : '' }}">
    <label for="ordem">Ordem</label>
</div>
<div class="input-field">
    <input type="url" name="link" id="link" class="validate"
        value="{{ isset($registro->link) ? $registro->link : '' }}">
    <label for="link">Link</label>
</div>
<div class="row">
    <div class="intput-field col s12">
        <select name="alinhamento" id="alinhamento">
            <option value="center-align" {{ isset($registro->alinhamento) && $registro->alinhamento == 'center-align' ? 'selected' : '' }}>Centralizado</option>
            <option value="left-align" {{ isset($registro->alinhamento) && $registro->alinhamento == 'left-align' ? 'selected' : '' }}>Esquerda</option>
            <option value="right-align" {{ isset($registro->alinhamento) && $registro->alinhamento == 'right-align' ? 'selected' : '' }}>Direita</option>
        </select>
        <label for="alinhamento">Alinhamento</label>
    </div>
</div>
<div class="row">
    <div class="input-field col s12">
        <select name="publicado" id="publicado">
            <option value="nao"
                {{ isset($registro->publicado) && $registro->publicado == 'nao' ? 'selected' : '' }}
                >Não</option>
            <option value="sim"
                {{ isset($registro->publicado) && $registro->publicado == 'sim' ? 'selected' : '' }}
                >Sim</option>
        </select>
        <label for="publicado">Publicado</label>
    </div>
</div>
<div class="row">
    <div class="file-field input-field col m9 s12">
        <div class="btn">
            <span>Imagem</span>
            <input type="file" name="imagem" id="imagem">
        </div>
        <div class="file-path-wrapper">
            <input type="text" class="file-path validate">
        </div>
    </div>
    <div class="col m3 s12">
        <img src="{{ asset($registro->imagem) }}" alt="Imagens do anúncio" width="120">
    </div>
</div>
@else
<div class="row">
    <div class="file-field input-field col m12 s12">
        <div class="btn">
            <span>Envio de Imagens</span>
            <input type="file" name="imagens[]" id="imagens[]" multiple>
        </div>
        <div class="file-path-wrapper">
            <input type="text" class="file-path validate">
        </div>
    </div>
</div>
@endif
