<?php

use Illuminate\Database\Seeder;
use App\User;

class UsuarioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $usuario = new User();
        $usuario->name = "Chucky Norris";
        $usuario->email = "admin@classificados.com.br";
        $usuario->password = bcrypt("123456");
        $usuario->save();
    }
}
