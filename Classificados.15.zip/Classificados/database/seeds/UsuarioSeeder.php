<?php

use Illuminate\Database\Seeder;
use App\User;

class UsuarioSeeder extends Seeder
{
    private $users = [
        ['email'=>'admin@classificados.com.br', 'name'=>'Chucky Norris', 'papel'=>'admin'],
        ['email'=>'gerente@classificados.com.br', 'name'=>'Maria da Penha', 'papel'=>'gerente'],
        ['email'=>'vendedor@classificados.com.br', 'name'=>'Silvio Santos', 'papel'=>'vendedor'],
    ];

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach ($this->users as $user) {
            if (User::where('email', '=', $user['email'])->count()) {
                $usuario = User::where('email', '=', $user['email'])->first();
                $usuario->update(['name'=>$user['name'], 'password'=>bcrypt("123456")]);
            } else {
                $usuario = User::create(['name'=>$user['name'], 'email'=>$user['email'], 'password'=>bcrypt("123456")]);
            }
            if (!$usuario->possuiPapel($user['papel'])) {
                $usuario->adicionarPapel($user['papel']);
            }
        }
    }
}
