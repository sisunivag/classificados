<?php

use Illuminate\Database\Seeder;
use App\Papel;

class PapelSeed extends Seeder
{
    private $papeis = [
        ['nome'=>'admin', 'descricao'=>'Administrador do Sistema'],
        ['nome'=>'gerente', 'descricao'=>'Gerente do Sistema'],
        ['nome'=>'vendedor', 'descricao'=>'Equipe de Vendas'],
    ];
    private $permissoes = [
        'admin'=>[],
        'gerente'=>[
            ['listar-usuarios', 'cadastrar-usuario', 'alterar-usuario', 'excluir-usuario'],
            ['listar-papeis-usuario', 'cadastrar-papel-usuario', 'excluir-papel-usuario'],
            ['listar-papeis', 'cadastrar-papel', 'alterar-papel', 'excluir-papel'],
            ['listar-permissoes', 'cadastrar-permissao', 'excluir-permissao'],
            ['listar-paginas', 'alterar-pagina'],
            ['listar-slides', 'cadastrar-slide', 'alterar-slide', 'excluir-slide'],
            ['listar-tipos', 'cadastrar-tipo', 'alterar-tipo', 'excluir-tipo'],
            ['listar-municipios', 'cadastrar-municipio', 'alterar-municipio', 'excluir-municipio'],
        ],
        'vendedor'=>[
            ['listar-anuncios', 'cadastrar-anuncio', 'alterar-anuncio', 'excluir-anuncio'],
            ['listar-imagens', 'cadastrar-imagem', 'alterar-imagem', 'excluir-imagem'],
        ],
    ];

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach ($this->papeis as $pap) {
            if (!Papel::where('nome', '=', $pap['nome'])->count()) {
                $papel = Papel::create([
                    'nome'=>$pap['nome'], 'descricao'=>$pap['descricao']
                ]);
            } else {
                $papel = Papel::where('nome', '=', $pap['nome'])->first();
            }

            foreach ($this->permissoes[$pap['nome']] as $permissoes) {
                foreach ($permissoes as $permissao) {
                    if (!$papel->possuiPermissao($permissao)) {
                        $papel->adicionarPermissao($permissao);
                    }
                }
            }
        }
    }
}
