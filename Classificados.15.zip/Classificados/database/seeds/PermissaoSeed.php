<?php

use Illuminate\Database\Seeder;
use App\Permissao;

class PermissaoSeed extends Seeder
{
    private $permissoes = [
        ['nome'=>'listar-usuarios', 'descricao'=>'Listar Usuários'],
        ['nome'=>'cadastrar-usuario', 'descricao'=>'Cadastrar Usuário'],
        ['nome'=>'alterar-usuario', 'descricao'=>'Alterar Usuário'],
        ['nome'=>'excluir-usuario', 'descricao'=>'Excluir Usuário'],
        ['nome'=>'listar-papeis-usuario', 'descricao'=>'Usuário - Listar Papéis'],
        ['nome'=>'cadastrar-papel-usuario', 'descricao'=>'Usuário - Cadastrar Papel'],
        ['nome'=>'excluir-papel-usuario', 'descricao'=>'Usuário - Excluir Papel'],
        ['nome'=>'listar-papeis', 'descricao'=>'Listar Papéis'],
        ['nome'=>'cadastrar-papel', 'descricao'=>'Cadastrar Papel'],
        ['nome'=>'alterar-papel', 'descricao'=>'Alterar Papel'],
        ['nome'=>'excluir-papel', 'descricao'=>'Excluir Papel'],
        ['nome'=>'listar-permissoes', 'descricao'=>'Listar Permissões'],
        ['nome'=>'cadastrar-permissao', 'descricao'=>'Cadastrar Permissão'],
        ['nome'=>'excluir-permissao', 'descricao'=>'Excluir Permissão'],
        ['nome'=>'listar-paginas', 'descricao'=>'Listar Páginas'],
        ['nome'=>'alterar-pagina', 'descricao'=>'Alterar Página'],
        ['nome'=>'listar-slides', 'descricao'=>'Listar Slides'],
        ['nome'=>'cadastrar-slide', 'descricao'=>'Cadastrar Slide'],
        ['nome'=>'alterar-slide', 'descricao'=>'Alterar Slide'],
        ['nome'=>'excluir-slide', 'descricao'=>'Excluir Slide'],
        ['nome'=>'listar-tipos', 'descricao'=>'Listar Tipos'],
        ['nome'=>'cadastrar-tipo', 'descricao'=>'Cadastrar Tipo'],
        ['nome'=>'alterar-tipo', 'descricao'=>'Alterar Tipo'],
        ['nome'=>'excluir-tipo', 'descricao'=>'Excluir Tipo'],
        ['nome'=>'listar-municipios', 'descricao'=>'Listar Municípios'],
        ['nome'=>'cadastrar-municipio', 'descricao'=>'Cadastrar Município'],
        ['nome'=>'alterar-municipio', 'descricao'=>'Alterar Município'],
        ['nome'=>'excluir-municipio', 'descricao'=>'Excluir Município'],
        ['nome'=>'listar-anuncios', 'descricao'=>'Listar Anúncios'],
        ['nome'=>'cadastrar-anuncio', 'descricao'=>'Cadastrar Anúncio'],
        ['nome'=>'alterar-anuncio', 'descricao'=>'Alterar Anúncio'],
        ['nome'=>'excluir-anuncio', 'descricao'=>'Excluir Anúncio'],
        ['nome'=>'listar-imagens', 'descricao'=>'Listar Imagens'],
        ['nome'=>'cadastrar-imagem', 'descricao'=>'Cadastrar Imagem'],
        ['nome'=>'alterar-imagem', 'descricao'=>'Alterar Imagem'],
        ['nome'=>'excluir-imagem', 'descricao'=>'Excluir Imagem'],
    ];

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach ($this->permissoes as $permissao) {
            if (!Permissao::where('nome', '=', $permissao['nome'])->count()) {
                Permissao::create(['nome'=>$permissao['nome'], 'descricao'=>$permissao['descricao']]);
            } else {
                $permissao = Permissao::where('nome', '=', $permissao['nome'])->first();
                $permissao->update(['nome'=>$permissao['nome'], 'descricao'=>$permissao['descricao']]);
            }
        }
    }
}
