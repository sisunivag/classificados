<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="center">Lista de Permissões - <?php echo e($papel->nome); ?></h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="<?php echo e(route('admin.home')); ?>" class="breadcrumb">Início</a>
                    <a href="<?php echo e(route('admin.papeis')); ?>" class="breadcrumb">Lista de Papéis</a>
                    <a class="breadcrumb">Lista de Permissões</a>
                </div>
            </div>
        </nav>
    </div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cadastrar-permissao')): ?>
    <div class="row">
        <form action="<?php echo e(route('admin.papeis.permissao.salvar', $papel->id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="input field">
                <select name="permissao_id" id="permissao_id">
                    <?php $__currentLoopData = $permissoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($permissao->id); ?>"><?php echo e($permissao->nome); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button class="btn blue">Cadastrar</button>
        </form>
    </div>
    <?php endif; ?>
    <div class="row">
        <table>
            <thead>
                <tr>
                    <th>Permissão</th>
                    <th>Descrição</th>
                    <th>Ação</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $papel->permissoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($permissao->nome); ?></td>
                    <td><?php echo e($permissao->descricao); ?></td>
                    <td>
                        <form action="<?php echo e(route('admin.papeis.permissao.excluir', [$papel->id, $permissao->id])); ?>"
                            method="post"
                            onsubmit="return confirm('Excluir <?php echo e($permissao->nome); ?>?')">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('delete')); ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cadastrar-permissao')): ?>
                            <button class="btn red">Excluir</button>
                            <?php else: ?>
                            <button class="btn disabled">Excluir</button>
                            <?php endif; ?>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>