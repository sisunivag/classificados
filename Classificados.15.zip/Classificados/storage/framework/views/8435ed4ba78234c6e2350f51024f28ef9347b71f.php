<?php if(isset($registro->imagem)): ?>
<div class="input-field">
    <input type="text" name="titulo" id="titulo" class="validate"
        value="<?php echo e(isset($registro->titulo) ? $registro->titulo : ''); ?>">
    <label for="titulo">Título</label>
</div>
<div class="input-field">
    <input type="text" name="descricao" id="descricao" class="validate"
        value="<?php echo e(isset($registro->descricao) ? $registro->descricao : ''); ?>">
    <label for="descricao">Descrição</label>
</div>
<div class="input-field">
    <input type="number" name="ordem"  id="ordem" min="1" step="1" class="validate"
        placeholder="Ex.: 1" value="<?php echo e(isset($registro->ordem) ? $registro->ordem : ''); ?>">
    <label for="ordem">Ordem</label>
</div>
<div class="row">
    <div class="file-field input-field col m9 s12">
        <div class="btn">
            <span>Imagem</span>
            <input type="file" name="imagem" id="imagem">
        </div>
        <div class="file-path-wrapper">
            <input type="text" class="file-path validate">
        </div>
    </div>
    <div class="col m3 s12">
        <img src="<?php echo e(asset($registro->imagem)); ?>" alt="Imagens do anúncio" width="120">
    </div>
</div>
<?php else: ?>
<div class="row">
    <div class="file-field input-field col m12 s12">
        <div class="btn">
            <span>Envio de Imagens</span>
            <input type="file" name="imagens[]" id="imagens[]" multiple>
        </div>
        <div class="file-path-wrapper">
            <input type="text" class="file-path validate">
        </div>
    </div>
</div>
<?php endif; ?>
