<div class="input-field">
    <input type="text" name="titulo" id="titulo" class="validate"
        value="<?php echo e(isset($registro->titulo) ? $registro->titulo : ''); ?>">
    <label for="titulo">Título</label>
</div>
<div class="input-field">
    <input type="text" name="descricao" id="descricao" class="validate"
        value="<?php echo e(isset($registro->descricao) ? $registro->descricao : ''); ?>">
    <label for="descricao">Descrição</label>
</div>
<div class="row">
    <div class="file-field input-field col m9 s12">
        <div class="btn">
            <span>Imagem</span>
            <input type="file" name="imagem" id="imagem">
        </div>
        <div class="file-path-wrapper">
            <input type="text" class="file-path validate">
        </div>
    </div>
    <div class="col m3 s12">
        <?php if(isset($registro->imagem)): ?>
        <img src="<?php echo e(asset($registro->imagem)); ?>" alt="Imagem do anúncio" width="120">
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="input-field col s12">
        <select name="finalidade" id="finalidade">
            <option value="Aluguel"
                <?php echo e(isset($registro->finalidade) && $registro->finalidade == 'Aluguel' ? 'selected' : ''); ?>

                >Aluguel</option>
            <option value="Troca"
                <?php echo e(isset($registro->finalidade) && $registro->finalidade == 'Troca' ? 'selected' : ''); ?>

                >Troca</option>
            <option value="Venda"
                <?php echo e(isset($registro->finalidade) && $registro->finalidade == 'Venda' ? 'selected' : ''); ?>

                >Venda</option>
        </select>
        <label for="finalidade">Finalidade</label>
    </div>
</div>
<div class="row">
    <div class="input-field col s12">
        <select name="tipo_id" id="tipo_id">
            <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($tipo->id); ?>"
                <?php echo e(isset($registro->tipo_id) && $registro->tipo_id == $tipo->id ? 'selected' : ''); ?>

                ><?php echo e($tipo->titulo); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="tipo_id">Tipo do Anúncio</label>
    </div>
</div>
<div class="input-field">
    <textarea name="endereco" id="endereco" class="materialize-textarea"
        ><?php echo e(isset($registro->endereco) ? $registro->endereco : ''); ?></textarea>
    <label for="endereco">Endereço</label>
</div>
<div class="input-field">
    <input type="text" name="cep" id="cep" class="validate" placeholder="Ex.: 78123-456"
        value="<?php echo e(isset($registro->cep) ? $registro->cep : ''); ?>">
    <label for="cep">CEP</label>
</div>
<div class="row">
    <div class="input-field col s12">
        <select name="municipio_id" id="municipio_id">
            <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($municipio->id); ?>"
                <?php echo e(isset($registro->municipio_id) && $registro->municipio_id == $municipio->id ? 'selected' : ''); ?>

                ><?php echo e($municipio->nome); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="municipio_id">Município</label>
    </div>
</div>
<div class="input-field">
    <input type="number" name="valor"  id="valor" min="0" step="0.01" class="validate"
        placeholder="Ex.: 1220.73" value="<?php echo e(isset($registro->valor) ? $registro->valor : ''); ?>">
    <label for="valor">Valor</label>
</div>
<div class="input-field">
    <textarea name="detalhes" id="detalhes" class="materialize-textarea"
        ><?php echo e(isset($registro->detalhes) ? $registro->detalhes : ''); ?></textarea>
    <label for="detalhes">Detalhes do Anúncio</label>
</div>
<div class="input-field">
    <textarea name="mapa" id="mapa" class="materialize-textarea"
        placeholder="Copie e cole o iframe do Google Maps"
        ><?php echo e(isset($registro->mapa) ? $registro->mapa : ''); ?></textarea>
    <label for="mapa">Mapa</label>
</div>
<div class="row">
    <div class="input-field col s12">
        <select name="publicado" id="publicado">
            <option value="nao"
                <?php echo e(isset($registro->publicado) && $registro->publicado == 'nao' ? 'selected' : ''); ?>

                >Não</option>
            <option value="sim"
                <?php echo e(isset($registro->publicado) && $registro->publicado == 'sim' ? 'selected' : ''); ?>

                >Sim</option>
        </select>
        <label for="publicado">Publicado</label>
    </div>
</div>
