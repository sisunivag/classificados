<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(isset($seo['titulo']) ? $seo['titulo'] : config('seo.titulo', 'Classificados')); ?></title>
    <meta name="description" content="<?php echo e(isset($seo['descricao']) ? $seo['descricao'] : config('seo.descricao')); ?>">
    
    <!-- Twitter -->
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@classificados" />
    <meta name="twitter:title" content="<?php echo e(isset($seo['titulo']) ? $seo['titulo'] : config('seo.titulo', 'Classificados')); ?>" />
    <meta name="twitter:description" content="<?php echo e(isset($seo['descricao']) ? $seo['descricao'] : config('seo.descricao')); ?>" />
    <meta name="twitter:image" content="<?php echo e(isset($seo['imagem']) ? $seo['imagem'] : config('seo.imagem')); ?>" />

    <!-- Open Graph Protocol: Facebook -->
    <meta property="og:title" content="<?php echo e(isset($seo['titulo']) ? $seo['titulo'] : config('seo.titulo', 'Classificados')); ?>" />
    <meta property="og:description" content="<?php echo e(isset($seo['descricao']) ? $seo['descricao'] : config('seo.descricao')); ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="<?php echo e(isset($seo['url']) ? $seo['url'] : config('app.url')); ?>" />
    <meta property="og:image" content="<?php echo e(isset($seo['imagem']) ? $seo['imagem'] : config('seo.imagem')); ?>" />

    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/materialize/dist/css/materialize.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body id="app-layout">
    <header>
        <?php echo $__env->make('layouts._site._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </header>

    <main>
        <?php if(Session::has('mensagem')): ?>
        <div class="container">
            <div class="row">
                <div class="card <?php echo e(Session::get('mensagem')['css-class']); ?>">
                    <div align="center" class="card-content">
                        <strong><?php echo e(Session::get('mensagem')['msg']); ?></strong>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="page-footer blue">
        <div class="container">
            <div class="row">
                <div class="col l6 s12">
                    <h5 class="white-text">Footer Content</h5>
                    <p class="grey-text text-lighten-4">You can use rows and columns here to organize your footer content.</p>
                </div>
                <div class="col l4 offset-l2 s12">
                    <h5 class="white-text">Links</h5>
                    <ul>
                        <li><a class="grey-text text-lighten-3" href="<?php echo e(route('site.home')); ?>">Home</a></li>
                        <li><a class="grey-text text-lighten-3" href="<?php echo e(route('site.sobre')); ?>">Sobre</a></li>
                        <li><a class="grey-text text-lighten-3" href="<?php echo e(route('site.contato')); ?>">Contatos</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <div class="container">
                © 2020 Copyright Univag Sistemas de Informação
                <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
        </div>
    </footer>

    <script type="text/javascript" src="<?php echo e(asset('lib/jquery/dist/jquery.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/materialize/dist/js/materialize.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/init.js')); ?>"></script>
</body>
</html>
