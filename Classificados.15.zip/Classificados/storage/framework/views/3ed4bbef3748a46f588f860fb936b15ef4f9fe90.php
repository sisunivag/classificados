<h2>Contato via Site</h2>
<p><strong>Nome:</strong> <?php echo e($request['nome']); ?></p>
<p><strong>Mensagem:</strong> <?php echo e($request['mensagem']); ?></p>