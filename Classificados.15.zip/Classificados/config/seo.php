<?php

return [
    'titulo'=>'Site de Classificados',
    /* Importante: a descrição deve possuir no máximo 155 caracteres. */
    'descricao'=>'Site de classificados para anúncios de aluguel, compra e venda',
    /* Aqui devemos inserir a URL para a imagem do site. */
    'imagem'=>'imagem do site',
];
