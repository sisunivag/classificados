<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Imagem extends Model
{
    protected $table = "imagens";

    public function anuncio()
    {
        return $this->belongsTo('App\Anuncio', 'anuncio_id');
    }
}
