<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Anuncio;
use App\Municipio;
use App\Slide;
use App\Tipo;

class HomeController extends Controller
{
    public function index()
    {
        $slides = Slide::where('publicado', '=', 'sim')->orderBy('ordem')->get();
        $tipos = Tipo::orderBy('titulo')->get();
        $municipios = Municipio::orderBy('nome')->get();
        $valores = $this->valores();
        $anuncios = Anuncio::where('publicado', '=', 'sim')->orderBy('id','desc')->paginate(20);
        $paginacao = true;
        return view('site.home', compact('slides', 'tipos', 'municipios', 'valores', 'anuncios', 'paginacao'));
    }

    public function busca(Request $request)
    {
        $busca = $request->all();
        $tipos = Tipo::orderBy('titulo')->get();
        $municipios = Municipio::orderBy('nome')->get();

        if ($busca['finalidade'] == 'Todos') {
            $finalidade = ['finalidade', '<>', null];
        } else {
            $finalidade = ['finalidade', '=', $busca['finalidade']];
        }
        if ($busca['tipo_id'] == 'Todos') {
            $tipo = ['tipo_id', '<>', null];
        } else {
            $tipo = ['tipo_id', '=', $busca['tipo_id']];
        }
        if ($busca['municipio_id'] == 'Todos') {
            $municipio = ['municipio_id', '<>', null];
        } else {
            $municipio = ['municipio_id', '=', $busca['municipio_id']];
        }

        $valores = $this->valores();

        if (isset($busca['endereco']) && trim($busca['endereco']) != '') {
            $endereco = [['endereco', 'like', '%'.$busca['endereco'].'%']];
        } else {
            $endereco = [['endereco', '<>', null]];
        }

        $anuncios = Anuncio::where([['publicado', '=', 'sim'], $finalidade, $tipo, $municipio])
            ->where($valores[$busca['valor']])
            ->where($endereco)
            ->orderBy('id','desc')->get();
        $paginacao = false;

        return view("site.busca", compact('busca', 'tipos', 'municipios', 'valores', 'anuncios', 'paginacao'));
    }

    private function valores()
    {
        return [
            [['valor', '>', 0]],
            [['valor', '<=', 500]],
            [['valor', '>', 500], ['valor', '<=', 1000]],
            [['valor', '>', 1000], ['valor', '<=', 5000]],
            [['valor', '>', 5000], ['valor', '<=', 10000]],
            [['valor', '>', 10000], ['valor', '<=', 50000]],
            [['valor', '>', 50000], ['valor', '<=', 100000]],
            [['valor', '>', 100000], ['valor', '<=', 200000]],
            [['valor', '>', 200000], ['valor', '<=', 300000]],
            [['valor', '>', 300000], ['valor', '<=', 500000]],
            [['valor', '>', 500000], ['valor', '<=', 1000000]],
            [['valor', '>', 1000000]]
        ];
    }
}
