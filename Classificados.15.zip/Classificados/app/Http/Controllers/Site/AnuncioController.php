<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Anuncio;

class AnuncioController extends Controller
{
    public function index($id)
    {
        $registro = Anuncio::find($id);

        if (!$registro) {
            \Session::flash('mensagem', ['msg'=>'Registro não encontrado: '.$id,
                'css-class'=>'red lighten-4']);
            return redirect()->route('site.home');
        } else if ($registro->publicado != 'sim') {
            \Session::flash('mensagem', ['msg'=>'Anúncio indisponível: '.$id,
                'css-class'=>'red lighten-4']);
            return redirect()->route('site.home');
        }

        $seo = [
            'titulo'=>$registro->titulo,
            'descricao'=>$registro->descricao,
            'imagem'=>asset($registro->imagem),
            'url'=>route('site.anuncio', [$registro->id, str_slug($registro->titulo, '_')]),
        ];

        $alinhamentos = ['center-align', 'left-align', 'right-align'];
        return view('site.anuncio', compact('registro', 'alinhamentos', 'seo'));
    }
}
