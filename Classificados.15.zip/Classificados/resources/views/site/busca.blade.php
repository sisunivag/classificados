@extends('layouts.site')

@section('content')
<div class="container">
    @include('layouts._site._lista_anuncios')
</div>
@endsection
