@extends('layouts.site')

@section('content')
<div class="container">
    <div class="row section">
        <h3 align="center">Anúncio</h3>
        <div class="divider"></div>
    </div>
    <div class="row section">
        <div class="col s12 m8">
            @if ($registro->imagens->count())
            <div class="row">
                <div class="slider">
                    <ul class="slides">
                        @foreach ($registro->imagens->sortBy('ordem') as $imagem)
                        <li>
                            <img src="{{ asset($imagem->imagem) }}" alt="{{ $imagem->descricao }}"
                                class="responsive-img">
                            <div class="caption center-align">
                                <h3>{{ $imagem->titulo }}</h3>
                                <h5>{{ $imagem->descricao }}</h5>
                            </div>
                        </li>
                        @endforeach
                    </ul>
                </div>
            </div>
            <div class="row" align="center">
                <button class="btn blue" onclick="sliderPrev()">Anterior</button>
                <button class="btn blue" onclick="sliderNext()">Próxima</button>
            </div>
            @else
                <img src="{{ asset($registro->imagem) }}" alt="{{ $registro->titulo }}"
                    class="responsive-img">
            @endif
        </div>
        <div class="col s12 m4">
            <h4>{{ $registro->titulo }}</h4>
            <blockquote>{{ $registro->descricao }}</blockquote>
            <p><strong>Código: </strong>{{ $registro->id }}</p>
            <p><strong>Finalidade: </strong>{{ $registro->finalidade }}</p>
            <p><strong>Tipo: </strong>{{ $registro->tipo->titulo }}</p>
            <p><strong>Endereço: </strong>{{ $registro->endereco }}</p>
            <p><strong>CEP: </strong>{{ $registro->cep }}</p>
            <p><strong>Município: </strong>{{ $registro->municipio->nome }}</p>
            <p><strong>Valor: </strong>R$ {{ number_format($registro->valor, 2, ",", ".") }}</p>
            <a href="{{  route('site.contato') }}"
               class="btn deep-orange darken-1">Entrar em contato</a>
        </div>
    </div>
    <div class="row section">
        <div class="col s12 m8">
            <div class="video-container">
                {!! $registro->mapa !!}
            </div>
        </div>
        <div class="col s12 m4">
            <h4>Detalhes do Anúncio:</h4>
            <p>{{ $registro->detalhes }}</p>
        </div>
    </div>
</div>
@endsection
