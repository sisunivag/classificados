@extends('layouts.app')

@section('content')

<div class="container">
    <h2>Principal</h2>
    <div class="row">
        <div class="col s12 m4">
            @can('listar-anuncios')
            <div class="card green darken-1">
                <div class="card-content white-text">
                    <span class="card-title">Anúncios</span>
                    <p>Lista de Anúncios</p>
                </div>
                <div class="card-action">
                    <a href="{{ route('admin.anuncios') }}" class="white-text">Acessar</a>
                </div>
            </div>
            @else
            <div class="card blue-grey lighten-4">
                <div class="card-content grey-text">
                    <span class="card-title">Anúncios</span>
                    <p>Lista de Anúncios</p>
                </div>
                <div class="card-action">
                    <a href="#!" class="grey-text">Acessar</a>
                </div>
            </div>
            @endcan
        </div>
        <div class="col s12 m4">
            @can('listar-tipos')
            <div class="card blue darken-1">
                <div class="card-content white-text">
                    <span class="card-title">Tipos</span>
                    <p>Lista de Tipos</p>
                </div>
                <div class="card-action">
                    <a href="{{ route('admin.tipos') }}" class="white-text">Acessar</a>
                </div>
            </div>
            @else
            <div class="card blue-grey lighten-4">
                <div class="card-content grey-text">
                    <span class="card-title">Tipos</span>
                    <p>Lista de Tipos</p>
                </div>
                <div class="card-action">
                    <a href="#!" class="grey-text">Acessar</a>
                </div>
            </div>
            @endcan
        </div>
        <div class="col s12 m4">
            @can('listar-municipios')
            <div class="card orange darken-1">
                <div class="card-content white-text">
                    <span class="card-title">Municípios</span>
                    <p>Lista de Municípios</p>
                </div>
                <div class="card-action">
                    <a href="{{ route('admin.municipios') }}" class="white-text">Acessar</a>
                </div>
            </div>
            @else
            <div class="card blue-grey lighten-4">
                <div class="card-content grey-text">
                    <span class="card-title">Municípios</span>
                    <p>Lista de Municípios</p>
                </div>
                <div class="card-action">
                    <a href="#!" class="grey-text">Acessar</a>
                </div>
            </div>
            @endcan
        </div>
    </div>
    <div class="row">
        <div class="col s12 m6">
            @can('listar-slides')
            <div class="card deep-purple">
                <div class="card-content white-text">
                    <span class="card-title">Slides</span>
                    <p>Lista de Slides</p>
                </div>
                <div class="card-action">
                    <a href="{{ route('admin.slides') }}" class="white-text">Acessar</a>
                </div>
            </div>
            @else
            <div class="card blue-grey lighten-4">
                <div class="card-content grey-text">
                    <span class="card-title">Slides</span>
                    <p>Lista de Slides</p>
                </div>
                <div class="card-action">
                    <a href="#!" class="grey-text">Acessar</a>
                </div>
            </div>
            @endcan
        </div>
        <div class="col s12 m6">
            @can('listar-usuarios')
            <div class="card deep-orange">
                <div class="card-content white-text">
                    <span class="card-title">Usuários</span>
                    <p>Lista de Usuários</p>
                </div>
                <div class="card-action">
                    <a href="{{ route('admin.usuarios') }}" class="white-text">Acessar</a>
                </div>
            </div>
            @else
            <div class="card blue-grey lighten-4">
                <div class="card-content grey-text">
                    <span class="card-title">Usuários</span>
                    <p>Lista de Usuários</p>
                </div>
                <div class="card-action">
                    <a href="#!" class="grey-text">Acessar</a>
                </div>
            </div>
            @endcan
        </div>
    </div>
    <div class="row">
        <div class="col s12 m6">
            @can('listar-papeis')
            <div class="card red darken-3">
                <div class="card-content white-text">
                    <span class="card-title">Papéis</span>
                    <p>Lista de Papéis</p>
                </div>
                <div class="card-action">
                    <a href="{{ route('admin.papeis') }}" class="white-text">Acessar</a>
                </div>
            </div>
            @else
            <div class="card blue-grey lighten-4">
                <div class="card-content grey-text">
                    <span class="card-title">Papéis</span>
                    <p>Lista de Papéis</p>
                </div>
                <div class="card-action">
                    <a href="#!" class="grey-text">Acessar</a>
                </div>
            </div>
            @endcan
        </div>
        <div class="col s12 m6">
            @can('listar-paginas')
            <div class="card purple darken-3">
                <div class="card-content white-text">
                    <span class="card-title">Páginas</span>
                    <p>Lista de Páginas</p>
                </div>
                <div class="card-action">
                    <a href="{{ route('admin.paginas') }}" class="white-text">Acessar</a>
                </div>
            </div>
            @else
            <div class="card blue-grey lighten-4">
                <div class="card-content grey-text">
                    <span class="card-title">Páginas</span>
                    <p>Lista de Páginas</p>
                </div>
                <div class="card-action">
                    <a href="#!" class="grey-text">Acessar</a>
                </div>
            </div>
            @endcan
        </div>
    </div>
</div>

@endsection
