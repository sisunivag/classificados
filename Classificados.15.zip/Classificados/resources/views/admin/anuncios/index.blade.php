@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="center">Lista de Anúncios</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="{{ route('admin.home') }}" class="breadcrumb">Início</a>
                    <a class="breadcrumb">Lista de Anúncios</a>
                </div>
            </div>
        </nav>
    </div>
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Título</th>
                <th>Finalidade</th>
                <th>Município</th>
                <th>Valor</th>
                <th>Imagem</th>
                <th>Publicado</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            @foreach($registros as $registro)
            <tr>
                <td>{{ $registro->id }}</td>
                <td>{{ $registro->titulo }}</td>
                <td>{{ $registro->finalidade }}</td>
                <td>{{ $registro->municipio->nome }}</td>
                <td>R$ {{ number_format($registro->valor, 2, ",", ".") }}</td>
                <td><img src="{{ asset($registro->imagem) }}" alt="" width="100"></td>
                <td>{{ $registro->publicado }}</td>
                <td>
                    <form action="{{ route('admin.anuncios.excluir', $registro->id) }}"
                        method="post"
                        onsubmit="return confirm('Excluir {{ $registro->titulo }}?')">
                        {{ csrf_field() }}
                        {{ method_field('delete') }}
                        @can('listar-imagens')
                        <a href="{{ route('admin.imagens', $registro->id) }}" class="btn blue">Galeria de Imagens</a><br />
                        @endcan
                        @can('alterar-anuncio')
                        <a href="{{ route('admin.anuncios.alterar', $registro->id) }}" class="btn orange">Alterar</a>
                        @endcan
                        @can('excluir-anuncio')
                        <button class="btn red">Excluir</button>
                        @endcan
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    @can('cadastrar-anuncio')
    <div class="row">
        <a class="btn blue" href="{{ route('admin.anuncios.cadastrar') }}">Cadastrar</a>
    </div>
    @endcan
</div>

@endsection