@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="center">Galeria de Imagens</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="{{ route('admin.home') }}" class="breadcrumb">Início</a>
                    <a href="{{ route('admin.anuncios') }}" class="breadcrumb">Lista de Anúncios</a>
                    <a class="breadcrumb">Galeria de Imagens</a>
                </div>
            </div>
        </nav>
    </div>
    <table>
        <thead>
            <tr>
                <th>Ordem</th>
                <th>Título</th>
                <th>Descrição</th>
                <th>Imagem</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            @foreach($registros as $registro)
            <tr>
                <td>{{ $registro->ordem }}</td>
                <td>{{ $registro->titulo }}</td>
                <td>{{ $registro->descricao }}</td>
                <td><img src="{{ asset($registro->imagem) }}" alt="{{ $registro->descricao }}" width="100"></td>
                <td>
                    <form action="{{ route('admin.imagens.excluir', $registro->id) }}"
                        method="post"
                        onsubmit="return confirm('Excluir {{ $registro->titulo }}?')">
                        {{ csrf_field() }}
                        {{ method_field('delete') }}
                        @can('alterar-imagem')
                        <a href="{{ route('admin.imagens.alterar', $registro->id) }}" class="btn orange">Alterar</a>
                        @endcan
                        @can('excluir-imagem')
                        <button class="btn red">Excluir</button>
                        @endcan
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    @can('cadastrar-imagem')
    <div class="row">
        <a class="btn blue" href="{{ route('admin.imagens.cadastrar', $anuncio->id) }}">Cadastrar</a>
    </div>
    @endcan
</div>

@endsection