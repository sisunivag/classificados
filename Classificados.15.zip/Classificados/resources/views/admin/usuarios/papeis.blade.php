@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="center">Lista de Papéis - {{ $usuario->name }}</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="{{ route('admin.home') }}" class="breadcrumb">Início</a>
                    <a href="{{ route('admin.usuarios') }}" class="breadcrumb">Lista de Usuários</a>
                    <a class="breadcrumb">Lista de Papéis</a>
                </div>
            </div>
        </nav>
    </div>
    @can('cadastrar-papel-usuario')
    <div class="row">
        <form action="{{ route('admin.usuarios.papel.salvar', $usuario->id) }}" method="post">
            {{ csrf_field() }}
            <div class="input field">
                <select name="papel_id" id="papel_id">
                    @foreach ($papeis as $papel)
                    <option value="{{ $papel->id }}">{{ $papel->nome }}</option>
                    @endforeach
                </select>
            </div>
            <button class="btn blue">Cadastrar</button>
        </form>
    </div>
    @endcan
    <div class="row">
        <table>
            <thead>
                <tr>
                    <th>Papel</th>
                    <th>Descrição</th>
                    <th>Ação</th>
                </tr>
            </thead>
            <tbody>
                @foreach($usuario->papeis as $papel)
                <tr>
                    <td>{{ $papel->nome }}</td>
                    <td>{{ $papel->descricao }}</td>
                    <td>
                        <form action="{{ route('admin.usuarios.papel.excluir', [$usuario->id, $papel->id]) }}"
                            method="post"
                            onsubmit="return confirm('Excluir {{ $papel->nome }}?')">
                            {{ csrf_field() }}
                            {{ method_field('delete') }}
                            @can('excluir-papel-usuario')
                            <button class="btn red">Excluir</button>
                            @endcan
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

@endsection