<nav>
    <div class="nav-wrapper blue">
        <div class="container">
            <a href="<?php echo e(route('admin.home')); ?>" class="brand-logo">
                <div class="hide-on-med-and-down">Classificados - Administração</div>
                Administração</a>
            <a href="#" data-target="mobile-demo" class="sidenav-trigger">
                <i class="material-icons">menu</i>
            </a>
            <ul class="right hide-on-med-and-down">
                <?php if(Auth::guest()): ?>
                <li><a href="<?php echo e(route('admin.login')); ?>">Login</a></li>
                <?php else: ?>
                <li><a href="<?php echo e(route('admin.home')); ?>">Início</a></li>
                <li>
                    <a href="#!" class="dropdown-trigger" data-target="dropdown1"><?php echo e(Auth::user()->name); ?>

                    <i class="material-icons right">arrow_drop_down</i></a>
                </li>
                <li><a href="<?php echo e(route('admin.logout')); ?>">Logout</a></li>
                <?php endif; ?>
                <li><a href="<?php echo e(route('site.home')); ?>" target="_blank">Site</a></li>
            </ul>
        </div>
    </div>
</nav>
<ul id="dropdown1" class="dropdown-content">
    <?php if(!Auth::guest()): ?>
    <li><a href="#!"><?php echo e(Auth::user()->name); ?></a></li>
    <?php endif; ?>
    <li class="divider"></li>
    <li><a href="<?php echo e(route('admin.slides')); ?>">Slides</a></li>
    <li><a href="<?php echo e(route('admin.usuarios')); ?>">Usuários</a></li>
    <li><a href="<?php echo e(route('admin.paginas')); ?>">Páginas</a></li>
    <li class="divider"></li>
    <li><a href="<?php echo e(route('admin.tipos')); ?>">Tipos</a></li>
    <li><a href="<?php echo e(route('admin.municipios')); ?>">Municípios</a></li>
    <li><a href="<?php echo e(route('admin.anuncios')); ?>">Anúncios</a></li>
</ul>
<ul class="sidenav" id="mobile-demo">
    <?php if(Auth::guest()): ?>
    <li><a href="<?php echo e(route('admin.login')); ?>">Login</a></li>
    <?php else: ?>
    <li><a href="<?php echo e(route('admin.home')); ?>">Início</a></li>
    <li class="divider"></li>
    <li><a href="#"><?php echo e(Auth::user()->name); ?></a></li>
    <li class="divider"></li>
    <li><a href="<?php echo e(route('admin.slides')); ?>">Slides</a></li>
    <li><a href="<?php echo e(route('admin.usuarios')); ?>">Usuários</a></li>
    <li><a href="<?php echo e(route('admin.paginas')); ?>">Páginas</a></li>
    <li><a href="<?php echo e(route('admin.tipos')); ?>">Tipos</a></li>
    <li><a href="<?php echo e(route('admin.municipios')); ?>">Municípios</a></li>
    <li><a href="<?php echo e(route('admin.anuncios')); ?>">Anúncios</a></li>
    <li class="divider"></li>
    <li><a href="<?php echo e(route('admin.logout')); ?>">Logout</a></li>
    <?php endif; ?>
    <li class="divider"></li>
    <li><a href="<?php echo e(route('site.home')); ?>" target="_blank">Site</a></li>
</ul>
