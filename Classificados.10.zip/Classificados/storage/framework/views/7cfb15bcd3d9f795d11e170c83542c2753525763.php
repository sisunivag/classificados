<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css"
    href="<?php echo e(asset('lib/materialize/dist/css/materialize.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
</head>
<body>
    <?php echo $__env->make('layouts._admin._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <ul class="sidenav" id="mobile-demo">
        <li><a href="#">Home</a></li>
    </ul>

    <main>
        <?php if(Session::has('mensagem')): ?>
        <div class="container">
            <div class="row">
                <div class="card <?php echo e(Session::get('mensagem')['css-class']); ?>">
                    <div align="center" class="card-content">
                        <strong><?php echo e(Session::get('mensagem')['msg']); ?></strong>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="page-footer blue">
        <div class="container">
            <div class="row">
                <div class="col l6 s12">
                    <h5 class="white-text">Administração</h5>
                    <p class="grey-text text-lighten-4">Módulo de administração do site de classificados.</p>
                </div>
                <div class="col l4 offset-l2 s12">
                    <h5 class="white-text">Links</h5>
                    <ul>
                        <?php if(Auth::guest()): ?>
                        <li><a class="grey-text text-lighten-3" href="<?php echo e(route('admin.login')); ?>">Login</a></li>
                        <?php else: ?>
                        <li><a class="grey-text text-lighten-3" href="<?php echo e(route('admin.home')); ?>">Início</a></li>
                        <?php endif; ?>
                        <li><a class="grey-text text-lighten-3" href="<?php echo e(route('site.home')); ?>" target="_blank">Site</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <div class="container">
                © 2020 Copyright Univag Sistemas de Informação
                <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
        </div>
    </footer>

    <script type="text/javascript" src="<?php echo e(asset('lib/jquery/dist/jquery.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/materialize/dist/js/materialize.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/init.js')); ?>"></script>
</body>
</html>
