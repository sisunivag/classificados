<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Pagina;

class PaginaController extends Controller
{
    public function sobre()
    {
        $pagina = Pagina::where('tipo', '=', 'sobre')->first();
        return view('site.sobre', compact('pagina'));
    }

    public function contato()
    {
        $pagina = Pagina::where('tipo', '=', 'contato')->first();
        return view('site.contato', compact('pagina'));
    }

    public function enviarContato(Request $request)
    {
        $mensagemErro = '';
        if (!isset($request['nome']) || trim($request['nome']) == '') {
            $mensagemErro .= 'nome não informado';
        }
        if (!isset($request['email']) || trim($request['email']) == '') {
            $mensagemErro .= ($mensagemErro != '' ? ", " : "") . 'e-mail não informado';
        } else {
            $email = trim($request['email']);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $mensagemErro .= ($mensagemErro != '' ? ", " : "") . 'e-mail inválido: '.$email;
            }
        }
        if (!isset($request['mensagem']) || trim($request['mensagem']) == '') {
            $mensagemErro .= ($mensagemErro != '' ? ", " : "") . 'mensagem não informada';
        }
        if ($mensagemErro != '') {
            \Session::flash('mensagem', ['msg'=>'Erro(s) encontrado(s): '.$mensagemErro.'.',
                'css-class'=>'red lighten-4']);
            return redirect()->route('site.contato');
        }

        $pagina = Pagina::where('tipo', '=', 'contato')->first();
        $email = $pagina->email;

        \Mail::send('emails.contato', ['request'=>$request],
            function($mensagem) use ($request, $email) {
                $mensagem->from(trim($request['email']), trim($request['nome']));
                $mensagem->to($email, 'Classificados - Central de Atendimento');
                $mensagem->subject('Contato pelo Site');
            }
        );
        
        \Session::flash('mensagem', ['msg'=>'Mensagem de contato enviado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('site.contato');
    }
}
