<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\User;

class UsuarioController extends Controller
{
    public function login(Request $request)
    {
        $dados = $request->all();
        
        if (Auth::attempt(['email'=>$dados['email'], 'password'=>$dados['password']]))
        {
            \Session::flash('mensagem', ['msg'=>'Login realizado com sucesso!',
                'css-class'=>'green lighten-4']);
            return redirect()->route('admin.home');
        }
        \Session::flash('mensagem', ['msg'=>'Erro: Dados incorretos!',
            'css-class'=>'red lighten-4']);
        return redirect()->route('admin.login');
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('admin.login');
    }

    public function index()
    {
        $usuarios = User::all();
        return view('admin.usuarios.index',  compact('usuarios'));
    }

    public function cadastrar()
    {
        return view('admin.usuarios.cadastrar');
    }

    public function salvar(Request $request)
    {
        $dados = $request->all();

        $mensagemErro = '';
        if (!isset($dados['name']) || trim($dados['name']) == '') {
            $mensagemErro .= 'nome não informado';
        }
        if (!isset($dados['email']) || trim($dados['email']) == '') {
            $mensagemErro .= ($mensagemErro != '' ? ", " : "") . 'e-mail não informado';
        } else {
            $email = trim($dados['email']);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $mensagemErro .= ($mensagemErro != '' ? ", " : "") . 'e-mail inválido: '.$email;
            }
        }
        if (!isset($dados['password']) || trim($request['password']) == '') {
            $mensagemErro .= ($mensagemErro != '' ? ", " : "") . 'senha não informada';
        }
        if ($mensagemErro != '') {
            \Session::flash('mensagem', ['msg'=>'Erro(s) encontrado(s): '.$mensagemErro.'.',
                'css-class'=>'red lighten-4']);
            return view('admin.usuarios.cadastrar');
        }

        $usuario = new User();
        $usuario->name = trim($dados['name']);
        $usuario->email = trim($dados['email']);
        $usuario->password = bcrypt(trim($dados['password']));

        $usuario->save();

        \Session::flash('mensagem', ['msg'=>'Usuário cadastrado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.usuarios');
    }

    public function alterar($id)
    {
        $usuario = User::find($id);
        return view('admin.usuarios.alterar', compact('usuario'));
    }

    public function atualizar(Request $request, $id)
    {
        $dados = $request->all();
        $usuario = User::find($id);

        $mensagemErro = '';
        if (!isset($dados['name']) || trim($dados['name']) == '') {
            $mensagemErro .= 'nome não informado';
        }
        if (!isset($dados['email']) || trim($dados['email']) == '') {
            $mensagemErro .= ($mensagemErro != '' ? ", " : "") . 'e-mail não informado';
        } else {
            $email = trim($dados['email']);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $mensagemErro .= ($mensagemErro != '' ? ", " : "") . 'e-mail inválido: '.$email;
            }
        }
        if ($mensagemErro != '') {
            \Session::flash('mensagem', ['msg'=>'Erro(s) encontrado(s): '.$mensagemErro.'.',
                'css-class'=>'red lighten-4']);
            return view('admin.usuarios.alterar', compact('usuario'));
        }

        if (isset($dados['password']) && strlen(trim($dados['password'])) > 5) {
            $dados['password'] = bcrypt(trim($dados['password']));
        } else {
            unset($dados['password']);
        }
        $dados['name'] = trim($dados['name']);
        $dados['email'] = trim($dados['email']);

        $usuario->update($dados);

        \Session::flash('mensagem', ['msg'=>'Usuário atualizado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.usuarios');
    }

    public function excluir($id)
    {
        User::find($id)->delete();

        \Session::flash('mensagem', ['msg'=>'Usuário excluído com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.usuarios');
    }
}
