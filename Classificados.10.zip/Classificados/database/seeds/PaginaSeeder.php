<?php

use Illuminate\Database\Seeder;
use App\Pagina;

class PaginaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $existe = Pagina::where('tipo', '=', 'sobre')->count();
        if ($existe) {
            $paginaSobre = Pagina::where('tipo', '=', 'sobre')->first();
        } else {
            $paginaSobre = new Pagina();
        }

        $paginaSobre->titulo = "Sobre a empresa";
        $paginaSobre->descricao = "Breve descrição sobre a empresa.";
        $paginaSobre->texto = "Texto detalhado sobre a empresa.";
        $paginaSobre->imagem = "img/classificados.png";
        $paginaSobre->mapa = '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3842.0339812515026!2d-56.097950685380354!3d-15.64317882342066!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x939dae6dca54546f%3A0x79d64fb4ddf01e79!2sUNIVAG%20-%20Cidade%20Universit%C3%A1ria!5e0!3m2!1spt-BR!2sbr!4v1585579058938!5m2!1spt-BR!2sbr" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>';
        $paginaSobre->tipo = "sobre";
        $paginaSobre->save();
        echo "Pagina Sobre criada/atualizada com sucesso!\n";

        $existe = Pagina::where('tipo', '=', 'contato')->count();
        if ($existe) {
            $paginaContato = Pagina::where('tipo', '=', 'contato')->first();
        } else {
            $paginaContato = new Pagina();
        }

        $paginaContato->titulo = "Entre em contato";
        $paginaContato->descricao = "Preencha o formulário";
        $paginaContato->texto = "Descrição detalhada do contato";
        $paginaContato->imagem = "img/classificados.png";
        $paginaContato->email = "contatos@classificados.com.br";
        $paginaContato->tipo = "contato";
        $paginaContato->save();
        echo "Pagina Contato criada/atualizada com sucesso!\n";
    }
}
