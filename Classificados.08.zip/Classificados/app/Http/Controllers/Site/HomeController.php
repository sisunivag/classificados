<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Anuncio;

class HomeController extends Controller
{
    public function index()
    {
        $registros = Anuncio::where('publicado', '=', 'sim')->orderBy('id','desc')->paginate(20);
        return view('site.home', compact('registros'));
    }
}
