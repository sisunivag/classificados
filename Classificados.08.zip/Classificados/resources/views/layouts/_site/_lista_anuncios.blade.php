<div class="row section">
    <h3 align="center">Anúncios</h3>
    <div class="divider"></div>
    <br>
    @include('layouts._site._filtros')
</div>
<div class="row section">
    @foreach($registros as $registro)
    <div class="col s12 m3">
        <div class="card">
            <div class="card-image">
                <a href="{{ route('site.anuncio', [$registro->id, str_slug($registro->titulo, '_')]) }}">
                    <img src="{{ asset($registro->imagem) }}" alt="{{ $registro->titulo }}"></a>
            </div>
            <div class="card-content">
                <p><strong class="deep-orange-text darken-1">{{ strtoupper($registro->finalidade) }}</strong></p>
                <p><strong>{{ $registro->titulo }}</strong></p>
                <p>{{ $registro->descricao }}</p>
                <p>R$ {{ number_format($registro->valor, 2, ",", ".") }}</p>
            </div>
            <div class="card-action">
                <a href="{{ route('site.anuncio', [$registro->id, str_slug($registro->titulo, '_')]) }}"
                    >Detalhes...</a>
            </div>
        </div>
    </div>
    @endforeach
</div>
<div class="row center">
    {{ $registros->links() }}
</div>
