<div class="row">
    <form action="">
        <div class="input-field col s6 m4">
            <select name="finalidade" id="finalidade">
                <option value="aluguel">Aluguel</option>
                <option value="troca">Troca</option>
                <option value="venda">Venda</option>
            </select>
            <label for="finalidade">Finalidade</label>
        </div>
        <div class="input-field col s6 m4">
            <select name="tipo" id="tipo">
                <option value="1">Automóvel</option>
                <option value="2">Eletrônico</option>
                <option value="3">Imóvel</option>
            </select>
            <label for="tipo">Tipo</label>
        </div>
        <div class="input-field col s6 m4">
            <select name="municipio" id="municipio">
                <option value="1">Chapada dos Guimarães</option>
                <option value="2">Cuiabá</option>
                <option value="3">Santo Antônio do Leverger</option>
                <option value="4">Várzea Grande</option>
            </select>
            <label for="municipio">Município</label>
        </div>
        <div class="input-field col s12 m4">
            <select name="valor" id="valor">
                <option value="1">Até R$ 500,00</option>
                <option value="2">R$ 500,00 a 1.000,00</option>
                <option value="3">R$ 1.000,00 a 5.000,00</option>
                <option value="4">R$ 5.000,00 a 10.000,00</option>
                <option value="5">R$ 10.000,00 a 50.000,00</option>
                <option value="6">R$ 50.000,00 a 100.000,00</option>
                <option value="7">R$ 100.000,00 a 200.000,00</option>
                <option value="8">R$ 200.000,00 a 300.000,00</option>
                <option value="9">R$ 300.000,00 a 500.000,00</option>
                <option value="10">R$ 500.000,00 a 1.000.000,00</option>
                <option value="11">Acima de R$ 1.000.000,00</option>
            </select>
            <label for="valor">Valor</label>
        </div>
        <div class="input-field col s12 m3">
            <input type="text" class="validate" name="endereco" id="endereco">
            <label for="endereco">Endereço</label>
        </div>
        <div class="input-field col s12 m2">
            <button class="btn deep-orange darken-1 right">Filtrar</button>
        </div>
    </form>
</div>
