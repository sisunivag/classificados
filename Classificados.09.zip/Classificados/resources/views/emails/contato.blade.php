<h2>Contato via Site</h2>
<p><strong>Nome:</strong> {{ $request['nome'] }}</p>
<p><strong>Mensagem:</strong> {{ $request['mensagem'] }}</p>