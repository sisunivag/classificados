<div class="slider">
    <ul class="slides">
        @foreach ($slides as $slide)
        <li
            @if ($slide->link)
            onclick="window.location='{{ $slide->link }}'" style="cursor: pointer;"
            @endif>
            <img src="{{ asset($slide->imagem) }}" alt="{{ $slide->titulo }}">
            <div class="caption {{ $alinhamentos[rand(0, 2)] }}">
                <h3>{{ $slide->titulo }}</h3>
                <h5>{{ $slide->descricao }}</h5>
            </div>
        </li>
        @endforeach
    </ul>
</div>
