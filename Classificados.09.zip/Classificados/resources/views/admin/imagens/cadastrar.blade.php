@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="center">Cadastrar Imagem</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="{{ route('admin.home') }}" class="breadcrumb">Início</a>
                    <a href="{{ route('admin.anuncios') }}" class="breadcrumb">Lista de Anúncios</a>
                    <a href="{{ route('admin.imagens', $anuncio->id) }}" class="breadcrumb">Galeria de Imagens</a>
                    <a class="breadcrumb">Cadastrar Imagem</a>
                </div>
            </div>
        </nav>
    </div>
    <div class="row">
        <form action="{{ route('admin.imagens.salvar', $anuncio->id) }}" method="post"
            enctype="multipart/form-data">
            {{ csrf_field() }}
            @include('admin.imagens._form')
            <button class="btn blue">Cadastrar</button>
        </form>
    </div>
</div>

@endsection
