@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="center">Alterar Imagem</h2>
    <div class="row">
        <nav>
            <div class="nav-wrapper blue">
                <div class="col s12">
                    <a href="{{ route('admin.home') }}" class="breadcrumb">Início</a>
                    <a href="{{ route('admin.anuncios') }}" class="breadcrumb">Lista de Anúncios</a>
                    <a href="{{ route('admin.imagens', $registro->anuncio->id) }}" class="breadcrumb">Galeria de Imagens</a>
                    <a class="breadcrumb">Alterar Imagem</a>
                </div>
            </div>
        </nav>
    </div>
    <div class="row">
        <form action="{{ route('admin.imagens.atualizar', $registro->id) }}" method="post"
            enctype="multipart/form-data">
            {{ csrf_field() }}
            <input type="hidden" name="_method" value="put">
            @include('admin.imagens._form')
            <button class="btn blue">Alterar</button>
        </form>
    </div>
</div>

@endsection
