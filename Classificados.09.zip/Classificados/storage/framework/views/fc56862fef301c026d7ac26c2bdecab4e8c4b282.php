<div class="slider">
    <ul class="slides">
        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li
            <?php if($slide->link): ?>
            onclick="window.location='<?php echo e($slide->link); ?>'" style="cursor: pointer;"
            <?php endif; ?>>
            <img src="<?php echo e(asset($slide->imagem)); ?>" alt="<?php echo e($slide->titulo); ?>">
            <div class="caption <?php echo e($alinhamentos[rand(0, 2)]); ?>">
                <h3><?php echo e($slide->titulo); ?></h3>
                <h5><?php echo e($slide->descricao); ?></h5>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
