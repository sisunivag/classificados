<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row section">
        <h3 align="center">Anúncio</h3>
        <div class="divider"></div>
    </div>
    <div class="row section">
        <div class="col s12 m8">
            <?php if($registro->imagens->count()): ?>
            <div class="row">
                <div class="slider">
                    <ul class="slides">
                        <?php $__currentLoopData = $registro->imagens->sortBy('ordem'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <img src="<?php echo e(asset($imagem->imagem)); ?>" alt="<?php echo e($imagem->descricao); ?>"
                                class="responsive-img">
                            <div class="caption center-align">
                                <h3><?php echo e($imagem->titulo); ?></h3>
                                <h5><?php echo e($imagem->descricao); ?></h5>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="row" align="center">
                <button class="btn blue" onclick="sliderPrev()">Anterior</button>
                <button class="btn blue" onclick="sliderNext()">Próxima</button>
            </div>
            <?php else: ?>
                <img src="<?php echo e(asset($registro->imagem)); ?>" alt="<?php echo e($registro->titulo); ?>"
                    class="responsive-img">
            <?php endif; ?>
        </div>
        <div class="col s12 m4">
            <h4><?php echo e($registro->titulo); ?></h4>
            <blockquote><?php echo e($registro->descricao); ?></blockquote>
            <p><strong>Código: </strong><?php echo e($registro->id); ?></p>
            <p><strong>Finalidade: </strong><?php echo e($registro->finalidade); ?></p>
            <p><strong>Tipo: </strong><?php echo e($registro->tipo->titulo); ?></p>
            <p><strong>Endereço: </strong><?php echo e($registro->endereco); ?></p>
            <p><strong>CEP: </strong><?php echo e($registro->cep); ?></p>
            <p><strong>Município: </strong><?php echo e($registro->municipio->nome); ?></p>
            <p><strong>Valor: </strong>R$ <?php echo e(number_format($registro->valor, 2, ",", ".")); ?></p>
            <a href="<?php echo e(route('site.contato')); ?>"
               class="btn deep-orange darken-1">Entrar em contato</a>
        </div>
    </div>
    <div class="row section">
        <div class="col s12 m8">
            <div class="video-container">
                <?php echo $registro->mapa; ?>

            </div>
        </div>
        <div class="col s12 m4">
            <h4>Detalhes do Anúncio:</h4>
            <p><?php echo e($registro->detalhes); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>