<div class="input-field">
    <input type="text" name="titulo" id="titulo" class="validate"
        value="<?php echo e(isset($registro->titulo) ? $registro->titulo : ''); ?>">
    <label for="titulo">Título</label>
</div>
