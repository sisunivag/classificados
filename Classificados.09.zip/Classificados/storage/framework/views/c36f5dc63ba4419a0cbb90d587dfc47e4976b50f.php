<div class="row section">
    <h3 align="center">Anúncios</h3>
    <div class="divider"></div>
    <br>
    <?php echo $__env->make('layouts._site._filtros', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<div class="row section">
    <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col s12 m3">
        <div class="card">
            <div class="card-image">
                <a href="<?php echo e(route('site.anuncio', [$registro->id, str_slug($registro->titulo, '_')])); ?>">
                    <img src="<?php echo e(asset($registro->imagem)); ?>" alt="<?php echo e($registro->titulo); ?>"></a>
            </div>
            <div class="card-content">
                <p><strong class="deep-orange-text darken-1"><?php echo e(strtoupper($registro->finalidade)); ?></strong></p>
                <p><strong><?php echo e($registro->titulo); ?></strong></p>
                <p><?php echo e($registro->descricao); ?></p>
                <p>R$ <?php echo e(number_format($registro->valor, 2, ",", ".")); ?></p>
            </div>
            <div class="card-action">
                <a href="<?php echo e(route('site.anuncio', [$registro->id, str_slug($registro->titulo, '_')])); ?>"
                    >Detalhes...</a>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="row center">
    <?php echo e($registros->links()); ?>

</div>
