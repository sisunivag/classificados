<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Anuncio;
use App\Municipio;

class MunicipioController extends Controller
{
    public function index()
    {
        $registros = Municipio::all();
        return view('admin.municipios.index',  compact('registros'));
    }

    public function cadastrar()
    {
        return view('admin.municipios.cadastrar');
    }

    public function salvar(Request $request)
    {
        $dados = $request->all();

        $registro = new Municipio();
        $registro->nome = $dados['nome'];
        $registro->estado = $dados['estado'];
        $registro->sigla_estado = $dados['sigla_estado'];

        $registro->save();

        \Session::flash('mensagem', ['msg'=>'Registro cadastrado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.municipios');
    }

    public function alterar($id)
    {
        $registro = Municipio::find($id);
        return view('admin.municipios.alterar', compact('registro'));
    }

    public function atualizar(Request $request, $id)
    {
        $registro = Municipio::find($id);
        $dados = $request->all();
        $registro->nome = $dados['nome'];
        $registro->estado = $dados['estado'];
        $registro->sigla_estado = $dados['sigla_estado'];

        $registro->update();

        \Session::flash('mensagem', ['msg'=>'Registro atualizado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.municipios');
    }

    public function excluir($id)
    {
        $municipio = Municipio::find($id);
        if (Anuncio::where('municipio_id', '=', $id)->count()) {
            $msg = 'Erro: Não é possível excluir "'.$municipio->nome.
                '", pois possui os seguintes anúncios cadastrados:';
            $anuncios = Anuncio::where('municipio_id', '=', $id)->get();
            foreach ($anuncios as $anuncio) {
                $msg .= ' '.$anuncio->id;
            }
            \Session::flash('mensagem', ['msg'=>$msg, 'css-class'=>'red lighten-4']);
            return redirect()->route('admin.municipios');
        }

        $municipio->delete();

        \Session::flash('mensagem', ['msg'=>'Registro excluído com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('admin.municipios');
    }
}
