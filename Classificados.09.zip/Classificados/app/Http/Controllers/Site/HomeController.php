<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Anuncio;
use App\Slide;

class HomeController extends Controller
{
    public function index()
    {
        $registros = Anuncio::where('publicado', '=', 'sim')->orderBy('id','desc')->paginate(20);
        $slides = Slide::where('publicado', '=', 'sim')->orderBy('ordem')->get();
        $alinhamentos = ['center-align', 'left-align', 'right-align'];
        return view('site.home', compact('registros', 'slides', 'alinhamentos'));
    }
}
