<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', ['as'=>'site.home', function(){
    return view('site.home');
}]);

Route::get('/sobre', ['as'=>'site.sobre',
    'uses'=>'Site\PaginaController@sobre'
]);

Route::get('/contato', ['as'=>'site.contato',
    'uses'=>'Site\PaginaController@contato'
]);
Route::post('/contato', ['as'=>'site.contato',
    'uses'=>'Site\PaginaController@enviarContato'
]);

Route::get('/anuncio/{id}/{titulo?}', ['as'=>'site.anuncio', function(){
    return view('site.anuncio');
}]);

Route::get('/admin/login', ['as'=>'admin.login', function(){
    return view('admin.login.index');
}]);

Route::post('/admin/login', ['as'=>'admin.login',
    'uses'=>'Admin\UsuarioController@login'
]);

Route::group(['middleware'=>'protegido'], function(){
    Route::get('/admin', ['as'=>'admin.home', function(){
        return view('admin.home.index');
    }]);

    Route::get('/admin/logout', ['as'=>'admin.logout',
        'uses'=>'Admin\UsuarioController@logout'
    ]);

    Route::get('/admin/usuarios', ['as'=>'admin.usuarios',
        'uses'=>'Admin\UsuarioController@index'
    ]);

    Route::get('/admin/usuarios/cadastrar', ['as'=>'admin.usuarios.cadastrar',
        'uses'=>'Admin\UsuarioController@cadastrar'
    ]);
    Route::post('/admin/usuarios/salvar', ['as'=>'admin.usuarios.salvar',
        'uses'=>'Admin\UsuarioController@salvar'
    ]);

    Route::get('/admin/usuarios/alterar/{id}', ['as'=>'admin.usuarios.alterar',
        'uses'=>'Admin\UsuarioController@alterar'
    ]);
    Route::put('/admin/usuarios/atualizar/{id}', ['as'=>'admin.usuarios.atualizar',
        'uses'=>'Admin\UsuarioController@atualizar'
    ]);

    Route::delete('/admin/usuarios/excluir/{id}', ['as'=>'admin.usuarios.excluir',
        'uses'=>'Admin\UsuarioController@excluir'
    ]);

    Route::get('/admin/paginas', ['as'=>'admin.paginas',
        'uses'=>'Admin\PaginaController@index'
    ]);
    Route::get('/admin/paginas/alterar/{id}', ['as'=>'admin.paginas.alterar',
        'uses'=>'Admin\PaginaController@alterar'
    ]);
    Route::put('/admin/paginas/atualizar/{id}', ['as'=>'admin.paginas.atualizar',
        'uses'=>'Admin\PaginaController@atualizar'
    ]);
});
