<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row section">
        <h3 align="center">Anúncio</h3>
        <div class="divider"></div>
    </div>
    <div class="row section">
        <div class="col s12 m8">
            <div class="row">
                <div class="slider">
                    <ul class="slides">
                        <li>
                            <img src="<?php echo e(asset('img/anuncio1.jpg')); ?>" alt="">
                            <div class="caption center-align">
                                <h3>Título da imagem</h3>
                                <h5>Descrição da imagem</h5>
                            </div>
                        </li>
                        <li>
                            <img src="<?php echo e(asset('img/anuncio2.jpg')); ?>" alt="">
                            <div class="caption left-align">
                                <h3>Título da imagem</h3>
                                <h5>Descrição da imagem</h5>
                            </div>
                        </li>
                        <li>
                            <img src="<?php echo e(asset('img/anuncio3.jpg')); ?>" alt="">
                            <div class="caption right-align">
                                <h3>Título da imagem</h3>
                                <h5>Descrição da imagem</h5>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row" align="center">
                <button class="btn blue" onclick="sliderPrev()">Anterior</button>
                <button class="btn blue" onclick="sliderNext()">Próxima</button>
            </div>
        </div>
        <div class="col s12 m4">
            <h4>Título do anúncio</h4>
            <blockquote>Descrição resumida do anúncio.</blockquote>
            <p><strong>Código: </strong> 552</p>
            <p><strong>Operação: </strong> Venda</p>
            <p><strong>Tipo: </strong> Imóvel</p>
            <p><strong>Endereço: </strong> Centro</p>
            <p><strong>CEP: </strong> 78123-456</p>
            <p><strong>Município: </strong> Várzea Grande</p>
            <p><strong>Valor: </strong> R$ 123.456,78</p>
            <a href="<?php echo e(route('site.contato')); ?>"
               class="btn deep-orange darken-1">Entrar em contato</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>