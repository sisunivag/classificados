<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Pagina;

class PaginaController extends Controller
{
    public function sobre()
    {
        $pagina = Pagina::where('tipo', '=', 'sobre')->first();
        return view('site.sobre', compact('pagina'));
    }

    public function contato()
    {
        $pagina = Pagina::where('tipo', '=', 'contato')->first();
        return view('site.contato', compact('pagina'));
    }

    public function enviarContato(Request $request)
    {
        $pagina = Pagina::where('tipo', '=', 'contato')->first();
        $email = $pagina->email;

        \Mail::send('emails.contato', ['request'=>$request],
            function($mensagem) use ($request, $email) {
                $mensagem->from($request['email'], $request['nome']);
                $mensagem->to($email, 'Classificados - Central de Atendimento');
                $mensagem->subject('Contato pelo Site');
        });

        \Session::flash('mensagem', ['msg'=>'Contato enviado com sucesso!',
            'css-class'=>'green lighten-4']);
        return redirect()->route('site.contato');
    }
}
